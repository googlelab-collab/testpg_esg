import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useDataUpload, useTemplateDownload } from "@/hooks/useDataUpload";
import { 
  Upload, 
  Download, 
  FileSpreadsheet, 
  AlertCircle, 
  CheckCircle,
  FileText,
  Database,
  Target,
  BarChart3,
  Users,
  Leaf,
  Shield
} from "lucide-react";

interface DataUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  organizationId: number;
}

export default function DataUploadModal({ isOpen, onClose, organizationId }: DataUploadModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<'metrics' | 'parameters'>('metrics');
  const [selectedModule, setSelectedModule] = useState<string>('');
  const [dragActive, setDragActive] = useState(false);
  
  const { toast } = useToast();
  const uploadMutation = useDataUpload();
  const templateDownloadMutation = useTemplateDownload();

  const modules = [
    { value: 'ghg_emissions', label: 'GHG Emissions', icon: Leaf },
    { value: 'energy_analytics', label: 'Energy Analytics', icon: BarChart3 },
    { value: 'water_management', label: 'Water Management', icon: Database },
    { value: 'employee_safety', label: 'Employee Safety', icon: Shield },
    { value: 'board_diversity', label: 'Board Diversity', icon: Users },
    { value: 'governance', label: 'Governance', icon: Target },
  ];

  const handleFileSelect = (file: File) => {
    if (file) {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv'
      ];
      
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid File Type",
          description: "Please upload Excel (.xlsx, .xls) or CSV files only",
          variant: "destructive",
        });
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast({
          title: "File Too Large",
          description: "Please upload files smaller than 10MB",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast({
        title: "No File Selected",
        description: "Please select a file to upload",
        variant: "destructive",
      });
      return;
    }

    if (uploadType === 'metrics' && !selectedModule) {
      toast({
        title: "Module Required",
        description: "Please select a module for metrics upload",
        variant: "destructive",
      });
      return;
    }

    await uploadMutation.mutateAsync({
      file: selectedFile,
      options: {
        organizationId,
        uploadType,
        module: selectedModule
      }
    });

    setSelectedFile(null);
    setSelectedModule('');
  };

  const handleTemplateDownload = async (templateType: 'metrics' | 'parameters') => {
    await templateDownloadMutation.mutateAsync(templateType);
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'xlsx':
      case 'xls':
        return <FileSpreadsheet className="h-8 w-8 text-green-600" />;
      case 'csv':
        return <FileText className="h-8 w-8 text-blue-600" />;
      default:
        return <FileText className="h-8 w-8 text-gray-600" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            ESG Data Upload & Management
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload">Upload Data</TabsTrigger>
            <TabsTrigger value="templates">Download Templates</TabsTrigger>
            <TabsTrigger value="validation">Data Validation</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Upload Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Upload Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Data Type</Label>
                    <Select value={uploadType} onValueChange={(value: 'metrics' | 'parameters') => setUploadType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metrics">ESG Metrics</SelectItem>
                        <SelectItem value="parameters">ESG Parameters</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {uploadType === 'metrics' && (
                    <div>
                      <Label>Target Module</Label>
                      <Select value={selectedModule} onValueChange={setSelectedModule}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select module" />
                        </SelectTrigger>
                        <SelectContent>
                          {modules.map((module) => {
                            const Icon = module.icon;
                            return (
                              <SelectItem key={module.value} value={module.value}>
                                <div className="flex items-center gap-2">
                                  <Icon className="h-4 w-4" />
                                  {module.label}
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="pt-4">
                    <Label>Expected Format</Label>
                    <div className="mt-2 p-3 bg-blue-50 rounded-lg text-sm">
                      {uploadType === 'metrics' ? (
                        <div>
                          <strong>Metrics Format:</strong>
                          <ul className="mt-1 list-disc list-inside text-gray-700">
                            <li>Metric Name, Value, Unit, Period</li>
                            <li>Date format: YYYY-MM-DD</li>
                            <li>Numeric values only</li>
                          </ul>
                        </div>
                      ) : (
                        <div>
                          <strong>Parameters Format:</strong>
                          <ul className="mt-1 list-disc list-inside text-gray-700">
                            <li>Parameter Name, Value, Category, Weight</li>
                            <li>Category: environmental, social, governance</li>
                            <li>Weight: 0.1 to 3.0</li>
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* File Upload Area */}
              <Card>
                <CardHeader>
                  <CardTitle>File Upload</CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                      dragActive
                        ? 'border-blue-500 bg-blue-50'
                        : selectedFile
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onDrop={handleDrop}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragActive(true);
                    }}
                    onDragLeave={() => setDragActive(false)}
                  >
                    {selectedFile ? (
                      <div className="space-y-3">
                        {getFileIcon(selectedFile.name)}
                        <div>
                          <p className="font-medium">{selectedFile.name}</p>
                          <p className="text-sm text-gray-500">
                            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedFile(null)}
                        >
                          Remove File
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                        <div>
                          <p className="text-lg font-medium">Drop your file here</p>
                          <p className="text-gray-500">or click to browse</p>
                        </div>
                        <Input
                          type="file"
                          accept=".xlsx,.xls,.csv"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileSelect(file);
                          }}
                          className="hidden"
                          id="file-upload"
                        />
                        <Label htmlFor="file-upload">
                          <Button variant="outline" className="cursor-pointer">
                            Select File
                          </Button>
                        </Label>
                      </div>
                    )}
                  </div>

                  {selectedFile && (
                    <div className="mt-4">
                      <Button
                        onClick={handleUpload}
                        disabled={uploadMutation.isPending}
                        className="w-full"
                      >
                        {uploadMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4 mr-2" />
                            Upload Data
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Upload Progress */}
            {uploadMutation.isPending && (
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Processing upload...</span>
                      <span>Please wait</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    ESG Metrics Template
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Download template for uploading ESG metrics data including GHG emissions, 
                    energy consumption, water usage, safety metrics, and governance indicators.
                  </p>
                  
                  <div className="bg-blue-50 p-3 rounded-lg text-sm">
                    <strong>Includes:</strong>
                    <ul className="mt-1 list-disc list-inside text-gray-700">
                      <li>Environmental metrics columns</li>
                      <li>Social metrics columns</li>
                      <li>Governance metrics columns</li>
                      <li>Data validation rules</li>
                      <li>Example data rows</li>
                    </ul>
                  </div>

                  <Button
                    onClick={() => handleTemplateDownload('metrics')}
                    disabled={templateDownloadMutation.isPending}
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Metrics Template
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    ESG Parameters Template
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Download template for configuring ESG parameters that affect 
                    score calculations including targets, weights, and baseline values.
                  </p>
                  
                  <div className="bg-green-50 p-3 rounded-lg text-sm">
                    <strong>Includes:</strong>
                    <ul className="mt-1 list-disc list-inside text-gray-700">
                      <li>Parameter configuration</li>
                      <li>Weight assignments</li>
                      <li>Target setting framework</li>
                      <li>Category classifications</li>
                      <li>Impact calculations</li>
                    </ul>
                  </div>

                  <Button
                    onClick={() => handleTemplateDownload('parameters')}
                    disabled={templateDownloadMutation.isPending}
                    variant="outline"
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Parameters Template
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Important:</strong> Always use the provided templates to ensure data 
                compatibility. Custom formats may result in upload errors or incorrect processing.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="validation" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Data Validation & Quality Checks</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Format Validation</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Automatic format checking and error detection
                    </p>
                  </div>
                  
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <Database className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Data Integrity</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Duplicate detection and consistency checks
                    </p>
                  </div>
                  
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <AlertCircle className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Quality Assurance</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Range validation and outlier detection
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Validation Rules</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Numeric values must be within expected ranges</li>
                    <li>• Dates must be in YYYY-MM-DD format</li>
                    <li>• Required fields cannot be empty</li>
                    <li>• Category values must match predefined options</li>
                    <li>• Duplicate entries will be flagged for review</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}