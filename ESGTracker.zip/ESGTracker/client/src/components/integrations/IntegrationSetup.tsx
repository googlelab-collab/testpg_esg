import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Database, 
  Cloud, 
  Globe, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  Loader,
  ExternalLink,
  Shield,
  Calendar,
  BarChart3
} from "lucide-react";

interface IntegrationSetupProps {
  isOpen: boolean;
  onClose: () => void;
  organizationId: number;
}

interface Integration {
  id: string;
  name: string;
  type: 'erp' | 'sustainability' | 'government' | 'benchmark';
  description: string;
  status: 'active' | 'inactive' | 'error' | 'pending';
  lastSync?: string;
  recordsCount?: number;
  config?: any;
}

export default function IntegrationSetup({ isOpen, onClose, organizationId }: IntegrationSetupProps) {
  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null);
  const [configData, setConfigData] = useState<any>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: integrations, isLoading } = useQuery({
    queryKey: [`/api/integrations/${organizationId}`],
    retry: false,
  });

  const setupMutation = useMutation({
    mutationFn: async (data: { type: string; config: any }) => {
      return await apiRequest(`/api/integrations/${organizationId}/setup`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Integration Setup Complete",
        description: "Integration has been configured successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/integrations/${organizationId}`] });
      setSelectedIntegration(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Setup Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async (integrationId: string) => {
      return await apiRequest(`/api/integrations/${organizationId}/sync/${integrationId}`, {
        method: 'POST',
      });
    },
    onSuccess: () => {
      toast({
        title: "Sync Complete",
        description: "Data has been synchronized successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/integrations/${organizationId}`] });
    },
  });

  const availableIntegrations = [
    {
      id: 'sap',
      name: 'SAP ERP',
      type: 'erp' as const,
      description: 'Connect to SAP for automated ESG data extraction',
      icon: Database,
      fields: [
        { key: 'baseUrl', label: 'SAP Base URL', type: 'url', required: true },
        { key: 'username', label: 'Username', type: 'text', required: true },
        { key: 'password', label: 'Password', type: 'password', required: true },
        { key: 'client', label: 'Client ID', type: 'text', required: true }
      ]
    },
    {
      id: 'oracle',
      name: 'Oracle ERP Cloud',
      type: 'erp' as const,
      description: 'Oracle Fusion Cloud ERP integration',
      icon: Cloud,
      fields: [
        { key: 'baseUrl', label: 'Oracle Base URL', type: 'url', required: true },
        { key: 'token', label: 'API Token', type: 'password', required: true },
        { key: 'username', label: 'Username', type: 'text', required: true }
      ]
    },
    {
      id: 'microsoft',
      name: 'Microsoft Sustainability Manager',
      type: 'sustainability' as const,
      description: 'Microsoft 365 sustainability data integration',
      icon: Cloud,
      fields: [
        { key: 'tenantId', label: 'Tenant ID', type: 'text', required: true },
        { key: 'clientId', label: 'Client ID', type: 'text', required: true },
        { key: 'clientSecret', label: 'Client Secret', type: 'password', required: true }
      ]
    },
    {
      id: 'salesforce',
      name: 'Salesforce Net Zero Cloud',
      type: 'sustainability' as const,
      description: 'Salesforce sustainability and carbon accounting',
      icon: Cloud,
      fields: [
        { key: 'instanceUrl', label: 'Instance URL', type: 'url', required: true },
        { key: 'accessToken', label: 'Access Token', type: 'password', required: true },
        { key: 'refreshToken', label: 'Refresh Token', type: 'password', required: false }
      ]
    },
    {
      id: 'epa',
      name: 'EPA APIs',
      type: 'government' as const,
      description: 'US EPA environmental data and emission factors',
      icon: Globe,
      fields: [
        { key: 'apiKey', label: 'EPA API Key', type: 'password', required: false },
        { key: 'region', label: 'Region', type: 'select', options: ['US', 'CA', 'EU'], required: true }
      ]
    },
    {
      id: 'cdp',
      name: 'CDP Platform',
      type: 'benchmark' as const,
      description: 'Carbon Disclosure Project benchmarks and scores',
      icon: BarChart3,
      fields: [
        { key: 'apiKey', label: 'CDP API Key', type: 'password', required: true },
        { key: 'organizationType', label: 'Organization Type', type: 'select', options: ['corporation', 'city', 'state'], required: true }
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return CheckCircle;
      case 'error': return AlertCircle;
      case 'pending': return Loader;
      default: return Settings;
    }
  };

  const handleSetupIntegration = (integrationId: string) => {
    const integration = availableIntegrations.find(i => i.id === integrationId);
    if (!integration) return;

    const config = { ...configData };
    setupMutation.mutate({ type: integrationId, config });
  };

  const renderConfigForm = (integration: any) => {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Configure {integration.name}</h3>
        <p className="text-sm text-gray-600">{integration.description}</p>
        
        {integration.fields.map((field: any) => (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={field.key}>
              {field.label} {field.required && <span className="text-red-500">*</span>}
            </Label>
            {field.type === 'select' ? (
              <Select 
                value={configData[field.key] || ''} 
                onValueChange={(value) => setConfigData(prev => ({ ...prev, [field.key]: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder={`Select ${field.label}`} />
                </SelectTrigger>
                <SelectContent>
                  {field.options?.map((option: string) => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                id={field.key}
                type={field.type}
                value={configData[field.key] || ''}
                onChange={(e) => setConfigData(prev => ({ ...prev, [field.key]: e.target.value }))}
                placeholder={`Enter ${field.label}`}
                required={field.required}
              />
            )}
          </div>
        ))}
        
        <div className="flex gap-2 pt-4">
          <Button 
            onClick={() => handleSetupIntegration(integration.id)}
            disabled={setupMutation.isPending}
            className="flex items-center gap-2"
          >
            {setupMutation.isPending ? <Loader className="h-4 w-4 animate-spin" /> : <Settings className="h-4 w-4" />}
            Setup Integration
          </Button>
          <Button variant="outline" onClick={() => setSelectedIntegration(null)}>
            Cancel
          </Button>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            System Integrations
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="available" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="available">Available Integrations</TabsTrigger>
            <TabsTrigger value="active">Active Integrations</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled Sync</TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-6">
            {selectedIntegration ? (
              <Card>
                <CardContent className="p-6">
                  {renderConfigForm(availableIntegrations.find(i => i.id === selectedIntegration))}
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {availableIntegrations.map((integration) => {
                  const Icon = integration.icon;
                  return (
                    <Card key={integration.id} className="hover:shadow-md transition-shadow">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                          <Icon className="h-6 w-6 text-blue-600" />
                          {integration.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">{integration.description}</p>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline">{integration.type.toUpperCase()}</Badge>
                          <Button 
                            size="sm" 
                            onClick={() => setSelectedIntegration(integration.id)}
                            className="flex items-center gap-2"
                          >
                            <Settings className="h-4 w-4" />
                            Configure
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="active" className="space-y-6">
            <div className="grid grid-cols-1 gap-4">
              {integrations?.map((integration: Integration) => {
                const StatusIcon = getStatusIcon(integration.status);
                return (
                  <Card key={integration.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <StatusIcon className="h-5 w-5" />
                          <div>
                            <h3 className="font-semibold">{integration.name}</h3>
                            <p className="text-sm text-gray-600">{integration.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className={getStatusColor(integration.status)}>
                            {integration.status}
                          </Badge>
                          {integration.status === 'active' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => syncMutation.mutate(integration.id)}
                              disabled={syncMutation.isPending}
                            >
                              Sync Now
                            </Button>
                          )}
                        </div>
                      </div>
                      {integration.lastSync && (
                        <div className="mt-4 text-sm text-gray-500">
                          Last sync: {new Date(integration.lastSync).toLocaleString()}
                          {integration.recordsCount && ` • ${integration.recordsCount} records`}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="scheduled" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Automated Sync Schedule
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">Daily Sync</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">EPA Data Sync</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">ERP Data Sync</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Benchmark Updates</span>
                        <Switch />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-semibold">Weekly Sync</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">ESG Score Calculation</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Report Generation</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Compliance Check</span>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-900">Data Security</h4>
                      <p className="text-blue-800 text-sm mt-1">
                        All integrations use encrypted connections and secure authentication. 
                        API credentials are stored using enterprise-grade encryption.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">98.5%</div>
                    <div className="text-sm text-gray-600">Uptime</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">2.3s</div>
                    <div className="text-sm text-gray-600">Avg Sync Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">45K</div>
                    <div className="text-sm text-gray-600">Records/Day</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}