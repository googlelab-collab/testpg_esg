interface ErrorMessageProps {
  error: Error | string | undefined;
  className?: string;
}

export default function ErrorMessage({ error, className = '' }: ErrorMessageProps) {
  if (!error) return null;
  
  const errorMessage = typeof error === 'string' ? error : error.message || 'An unexpected error occurred';
  
  return (
    <div className={`text-red-600 bg-red-50 p-4 rounded-lg border border-red-200 ${className}`}>
      <h3 className="font-semibold mb-2">Error</h3>
      <p>{errorMessage}</p>
    </div>
  );
}