import cron from 'node-cron';
import { integrations } from './thirdPartyAPIs';
import { storage } from '../storage';
import nodemailer from 'nodemailer';

// Email configuration
const emailTransporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD
  }
});

export class ScheduledJobs {
  
  // Daily data sync job
  startDailyDataSync() {
    // Run daily at 2 AM
    cron.schedule('0 2 * * *', async () => {
      console.log('Starting daily data sync...');
      
      try {
        const organizations = await storage.getAllOrganizations();
        
        for (const org of organizations) {
          const integrationConfigs = await this.getOrganizationIntegrations(org.id);
          
          if (integrationConfigs.length > 0) {
            const results = await integrations.syncAllIntegrations(org.id, integrationConfigs);
            
            // Send notification email
            await this.sendSyncNotification(org, results);
            
            // Log results
            console.log(`Data sync completed for organization ${org.id}:`, results);
          }
        }
      } catch (error) {
        console.error('Daily data sync failed:', error);
        await this.sendErrorNotification('Daily Data Sync', error.message);
      }
    });
  }

  // Weekly ESG score calculation and report generation
  startWeeklyReporting() {
    // Run weekly on Sundays at 6 AM
    cron.schedule('0 6 * * 0', async () => {
      console.log('Starting weekly ESG reporting...');
      
      try {
        const organizations = await storage.getAllOrganizations();
        
        for (const org of organizations) {
          // Calculate updated ESG scores
          await this.calculateWeeklyESGScores(org.id);
          
          // Generate automated reports
          await this.generateWeeklyReports(org.id);
          
          // Send summary email
          await this.sendWeeklyReportNotification(org);
        }
      } catch (error) {
        console.error('Weekly reporting failed:', error);
        await this.sendErrorNotification('Weekly Reporting', error.message);
      }
    });
  }

  // Monthly compliance check
  startMonthlyComplianceCheck() {
    // Run monthly on the 1st at 8 AM
    cron.schedule('0 8 1 * *', async () => {
      console.log('Starting monthly compliance check...');
      
      try {
        const organizations = await storage.getAllOrganizations();
        
        for (const org of organizations) {
          const complianceStatus = await this.checkComplianceStatus(org.id);
          
          if (complianceStatus.hasIssues) {
            await this.sendComplianceAlert(org, complianceStatus);
          }
          
          // Update compliance frameworks
          await this.updateComplianceFrameworks(org.id);
        }
      } catch (error) {
        console.error('Monthly compliance check failed:', error);
        await this.sendErrorNotification('Compliance Check', error.message);
      }
    });
  }

  // Regulatory updates monitoring
  startRegulatoryMonitoring() {
    // Run twice daily at 9 AM and 5 PM
    cron.schedule('0 9,17 * * *', async () => {
      console.log('Checking for regulatory updates...');
      
      try {
        const updates = await this.fetchRegulatoryUpdates();
        
        if (updates.length > 0) {
          await this.processRegulatoryUpdates(updates);
          await this.notifyStakeholders(updates);
        }
      } catch (error) {
        console.error('Regulatory monitoring failed:', error);
      }
    });
  }

  // Data quality monitoring
  startDataQualityMonitoring() {
    // Run every 6 hours
    cron.schedule('0 */6 * * *', async () => {
      console.log('Running data quality checks...');
      
      try {
        const organizations = await storage.getAllOrganizations();
        
        for (const org of organizations) {
          const qualityIssues = await this.checkDataQuality(org.id);
          
          if (qualityIssues.length > 0) {
            await this.sendDataQualityAlert(org, qualityIssues);
          }
        }
      } catch (error) {
        console.error('Data quality monitoring failed:', error);
      }
    });
  }

  // Helper methods
  private async getOrganizationIntegrations(orgId: number) {
    // Fetch integration configurations from database
    // This would be stored in an integrations table
    return [
      {
        type: 'epa',
        enabled: true
      }
      // Add more based on organization setup
    ];
  }

  private async calculateWeeklyESGScores(orgId: number) {
    const parameters = await storage.getESGParameters(orgId);
    
    // Calculate ESG scores using the server-side calculation logic
    const { calculateESGScore } = await import('../utils/esgCalculations');
    const scores = await calculateESGScore(parameters);
    
    // Save the new score
    await storage.createESGScore({
      organizationId: orgId,
      overallScore: scores.overallScore,
      environmentalScore: scores.environmentalScore,
      socialScore: scores.socialScore,
      governanceScore: scores.governanceScore,
      calculatedAt: new Date()
    });
  }

  private async generateWeeklyReports(orgId: number) {
    // Auto-generate weekly reports for all frameworks
    const frameworks = ['GRI', 'SASB', 'TCFD', 'EU-CSRD'];
    
    for (const framework of frameworks) {
      // Generate and store report
      // Implementation would call the report generation service
    }
  }

  private async checkComplianceStatus(orgId: number) {
    const frameworks = await storage.getComplianceFrameworks(orgId);
    const issues = [];
    
    for (const framework of frameworks) {
      if (framework.status !== 'compliant') {
        issues.push({
          framework: framework.frameworkName,
          status: framework.status,
          lastUpdated: framework.lastAssessment
        });
      }
    }
    
    return {
      hasIssues: issues.length > 0,
      issues
    };
  }

  private async updateComplianceFrameworks(orgId: number) {
    // Update compliance statuses based on current data
    const frameworks = await storage.getComplianceFrameworks(orgId);
    
    for (const framework of frameworks) {
      // Check if metrics meet compliance requirements
      const isCompliant = await this.assessFrameworkCompliance(orgId, framework.frameworkName);
      
      if (framework.status !== (isCompliant ? 'compliant' : 'non_compliant')) {
        await storage.updateComplianceFramework(framework.id, {
          status: isCompliant ? 'compliant' : 'non_compliant',
          lastAssessment: new Date()
        });
      }
    }
  }

  private async assessFrameworkCompliance(orgId: number, frameworkName: string): Promise<boolean> {
    // Assess compliance based on framework requirements
    const metrics = await storage.getESGMetrics(orgId);
    
    // Framework-specific compliance logic
    switch (frameworkName) {
      case 'GRI':
        return this.assessGRICompliance(metrics);
      case 'SASB':
        return this.assessSASBCompliance(metrics);
      case 'TCFD':
        return this.assessTCFDCompliance(metrics);
      default:
        return true;
    }
  }

  private assessGRICompliance(metrics: any[]): boolean {
    // GRI compliance requirements
    const requiredMetrics = ['ghg_emissions', 'energy_consumption', 'water_usage'];
    return requiredMetrics.every(metric => 
      metrics.some(m => m.metricType === metric && m.verificationStatus === 'verified')
    );
  }

  private assessSASBCompliance(metrics: any[]): boolean {
    // SASB compliance requirements
    return metrics.filter(m => m.verificationStatus === 'verified').length >= 5;
  }

  private assessTCFDCompliance(metrics: any[]): boolean {
    // TCFD compliance requirements
    const climateMetrics = metrics.filter(m => 
      m.metricType.includes('climate') || m.metricType.includes('ghg')
    );
    return climateMetrics.length >= 3;
  }

  private async fetchRegulatoryUpdates() {
    // Fetch from regulatory data sources
    return [];
  }

  private async processRegulatoryUpdates(updates: any[]) {
    // Process and store regulatory updates
  }

  private async checkDataQuality(orgId: number) {
    const metrics = await storage.getESGMetrics(orgId);
    const issues = [];
    
    // Check for missing data
    const cutoffDate = new Date();
    cutoffDate.setDays(cutoffDate.getDate() - 30);
    
    const recentMetrics = metrics.filter(m => new Date(m.createdAt) > cutoffDate);
    
    if (recentMetrics.length === 0) {
      issues.push('No data updated in the last 30 days');
    }
    
    // Check for unverified data
    const unverifiedCount = metrics.filter(m => m.verificationStatus !== 'verified').length;
    if (unverifiedCount > metrics.length * 0.3) {
      issues.push(`${unverifiedCount} metrics require verification`);
    }
    
    return issues;
  }

  // Notification methods
  private async sendSyncNotification(org: any, results: any[]) {
    const successCount = results.filter(r => r.status === 'success').length;
    const errorCount = results.filter(r => r.status === 'error').length;
    
    await emailTransporter.sendMail({
      to: org.notificationEmail || 'admin@esgsuite.com',
      subject: `ESG Data Sync Complete - ${org.name}`,
      html: `
        <h2>Daily Data Sync Report</h2>
        <p>Organization: ${org.name}</p>
        <p>Successful integrations: ${successCount}</p>
        <p>Failed integrations: ${errorCount}</p>
        <p>Total records processed: ${results.reduce((sum, r) => sum + (r.recordsProcessed || 0), 0)}</p>
        ${errorCount > 0 ? `<p style="color: red;">Errors occurred in: ${results.filter(r => r.status === 'error').map(r => r.type).join(', ')}</p>` : ''}
      `
    });
  }

  private async sendWeeklyReportNotification(org: any) {
    await emailTransporter.sendMail({
      to: org.notificationEmail || 'admin@esgsuite.com',
      subject: `Weekly ESG Report - ${org.name}`,
      html: `
        <h2>Weekly ESG Performance Summary</h2>
        <p>Your weekly ESG reports have been generated and are available in the dashboard.</p>
        <p>Please review the latest scores and compliance status.</p>
      `
    });
  }

  private async sendComplianceAlert(org: any, complianceStatus: any) {
    await emailTransporter.sendMail({
      to: org.notificationEmail || 'admin@esgsuite.com',
      subject: `Compliance Alert - ${org.name}`,
      html: `
        <h2>ESG Compliance Issues Detected</h2>
        <p>The following compliance issues require attention:</p>
        <ul>
          ${complianceStatus.issues.map((issue: any) => `
            <li>${issue.framework}: ${issue.status} (Last updated: ${issue.lastUpdated})</li>
          `).join('')}
        </ul>
        <p>Please review and update your ESG data to maintain compliance.</p>
      `
    });
  }

  private async sendDataQualityAlert(org: any, issues: string[]) {
    await emailTransporter.sendMail({
      to: org.notificationEmail || 'admin@esgsuite.com',
      subject: `Data Quality Alert - ${org.name}`,
      html: `
        <h2>Data Quality Issues Detected</h2>
        <ul>
          ${issues.map(issue => `<li>${issue}</li>`).join('')}
        </ul>
        <p>Please review and improve data quality to ensure accurate ESG reporting.</p>
      `
    });
  }

  private async sendErrorNotification(jobName: string, error: string) {
    await emailTransporter.sendMail({
      to: 'admin@esgsuite.com',
      subject: `System Error: ${jobName}`,
      html: `
        <h2>System Error Occurred</h2>
        <p>Job: ${jobName}</p>
        <p>Error: ${error}</p>
        <p>Please check the system logs for more details.</p>
      `
    });
  }

  private async notifyStakeholders(updates: any[]) {
    // Notify relevant stakeholders about regulatory updates
  }

  // Start all scheduled jobs
  startAllJobs() {
    console.log('Starting all scheduled jobs...');
    this.startDailyDataSync();
    this.startWeeklyReporting();
    this.startMonthlyComplianceCheck();
    this.startRegulatoryMonitoring();
    this.startDataQualityMonitoring();
    console.log('All scheduled jobs started successfully');
  }
}

export const scheduledJobs = new ScheduledJobs();