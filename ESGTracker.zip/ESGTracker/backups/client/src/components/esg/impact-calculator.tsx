import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { TrendingUp, TrendingDown, Activity, Target } from "lucide-react";
import type { ESGParameter } from "@shared/schema";

interface ImpactCalculatorProps {
  parameters: ESGParameter[];
  organizationId: number;
  category?: string;
}

interface ImpactResult {
  environmentalImpact: number;
  socialImpact: number;
  governanceImpact: number;
  overallImpact: number;
  parameterChange: number;
}

export function ImpactCalculator({ parameters, organizationId, category }: ImpactCalculatorProps) {
  const [selectedParameter, setSelectedParameter] = useState<ESGParameter | null>(null);
  const [simulatedValue, setSimulatedValue] = useState<number>(0);
  const [impactResult, setImpactResult] = useState<ImpactResult | null>(null);

  // Calculate impact when parameter changes
  const calculateImpact = async (parameterId: number, newValue: string) => {
    try {
      const response = await fetch("/api/parameter-impact-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          organizationId,
          parameterId,
          newValue
        })
      });
      
      if (response.ok) {
        const result = await response.json();
        setImpactResult(result);
      }
    } catch (error) {
      console.error("Impact calculation error:", error);
    }
  };

  // Auto-calculate when simulation changes
  useEffect(() => {
    if (selectedParameter && simulatedValue !== parseFloat(selectedParameter.currentValue)) {
      calculateImpact(selectedParameter.id, simulatedValue.toString());
    }
  }, [selectedParameter, simulatedValue, organizationId]);

  const filteredParameters = category 
    ? parameters.filter(p => p.category === category)
    : parameters;

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-purple-800">
            <Activity className="h-5 w-5" />
            Real-time ESG Impact Calculator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Parameter Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredParameters.map((param) => (
              <Card 
                key={param.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                  selectedParameter?.id === param.id 
                    ? 'ring-2 ring-purple-500 bg-purple-50' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => {
                  setSelectedParameter(param);
                  setSimulatedValue(parseFloat(param.currentValue));
                }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-900">
                      {param.parameterName}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {param.category}
                    </Badge>
                  </div>
                  <div className="text-lg font-semibold text-purple-600">
                    {parseFloat(param.currentValue).toFixed(1)} {param.unit}
                  </div>
                  {param.targetValue && (
                    <div className="flex items-center gap-1 mt-1">
                      <Target className="h-3 w-3 text-gray-500" />
                      <span className="text-xs text-gray-600">
                        Target: {param.targetValue} {param.unit}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Parameter Simulation */}
          {selectedParameter && (
            <Card className="border-indigo-200 bg-indigo-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-indigo-800 text-lg">
                  Simulate: {selectedParameter.parameterName}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Current Value</span>
                    <span className="text-sm font-medium">
                      {parseFloat(selectedParameter.currentValue).toFixed(1)} {selectedParameter.unit}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Simulated Value</span>
                    <span className="text-sm font-medium text-indigo-600">
                      {simulatedValue.toFixed(1)} {selectedParameter.unit}
                    </span>
                  </div>
                  
                  <input
                    type="range"
                    min="0"
                    max={selectedParameter.targetValue ? 
                      Math.max(100, parseFloat(selectedParameter.targetValue) * 1.2) : 100}
                    step="0.1"
                    value={simulatedValue}
                    onChange={(e) => setSimulatedValue(parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>0</span>
                    <span>
                      {selectedParameter.targetValue ? 
                        Math.max(100, parseFloat(selectedParameter.targetValue) * 1.2) : 100}
                    </span>
                  </div>
                </div>

                {/* Impact Results */}
                {impactResult && (
                  <div className="space-y-3 mt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-green-700">Environmental</span>
                          <div className="flex items-center gap-1">
                            {impactResult.environmentalImpact > 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-600" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-600" />
                            )}
                            <span className={`text-sm font-bold ${
                              impactResult.environmentalImpact > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {impactResult.environmentalImpact > 0 ? '+' : ''}
                              {impactResult.environmentalImpact.toFixed(2)}
                            </span>
                          </div>
                        </div>
                        <Progress 
                          value={Math.abs(impactResult.environmentalImpact) * 10} 
                          className="h-2"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-blue-700">Social</span>
                          <div className="flex items-center gap-1">
                            {impactResult.socialImpact > 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-600" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-600" />
                            )}
                            <span className={`text-sm font-bold ${
                              impactResult.socialImpact > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {impactResult.socialImpact > 0 ? '+' : ''}
                              {impactResult.socialImpact.toFixed(2)}
                            </span>
                          </div>
                        </div>
                        <Progress 
                          value={Math.abs(impactResult.socialImpact) * 10} 
                          className="h-2"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-purple-700">Governance</span>
                          <div className="flex items-center gap-1">
                            {impactResult.governanceImpact > 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-600" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-600" />
                            )}
                            <span className={`text-sm font-bold ${
                              impactResult.governanceImpact > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {impactResult.governanceImpact > 0 ? '+' : ''}
                              {impactResult.governanceImpact.toFixed(2)}
                            </span>
                          </div>
                        </div>
                        <Progress 
                          value={Math.abs(impactResult.governanceImpact) * 10} 
                          className="h-2"
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">Overall Impact</span>
                          <div className="flex items-center gap-1">
                            {impactResult.overallImpact > 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-600" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-600" />
                            )}
                            <span className={`text-sm font-bold ${
                              impactResult.overallImpact > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {impactResult.overallImpact > 0 ? '+' : ''}
                              {impactResult.overallImpact.toFixed(2)}
                            </span>
                          </div>
                        </div>
                        <Progress 
                          value={Math.abs(impactResult.overallImpact) * 10} 
                          className="h-2"
                        />
                      </div>
                    </div>

                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-xs text-gray-600 mb-1">Impact Analysis</div>
                      <div className="text-sm">
                        A <span className="font-medium text-indigo-600">
                          {Math.abs(impactResult.parameterChange).toFixed(1)} {selectedParameter.unit}
                        </span> change in <span className="font-medium">{selectedParameter.parameterName}</span> would result in an overall ESG score change of{' '}
                        <span className={`font-bold ${
                          impactResult.overallImpact > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {impactResult.overallImpact > 0 ? '+' : ''}
                          {impactResult.overallImpact.toFixed(2)} points
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}