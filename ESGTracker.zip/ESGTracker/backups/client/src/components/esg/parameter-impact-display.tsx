import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";

interface ParameterImpactDisplayProps {
  parameterName: string;
  category: string;
  currentValue: number;
  targetValue?: number;
  unit: string;
  impactWeight: number;
  environmentalImpact: number;
  socialImpact: number;
  governanceImpact: number;
  overallImpact: number;
}

export function ParameterImpactDisplay({
  parameterName,
  category,
  currentValue,
  targetValue,
  unit,
  impactWeight,
  environmentalImpact,
  socialImpact,
  governanceImpact,
  overallImpact
}: ParameterImpactDisplayProps) {
  const getImpactColor = (impact: number) => {
    if (impact > 0.5) return "text-green-600";
    if (impact > 0) return "text-yellow-600";
    if (impact > -0.5) return "text-orange-600";
    return "text-red-600";
  };

  const getImpactIcon = (impact: number) => {
    return impact > 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />;
  };

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-blue-800">{parameterName}</CardTitle>
          <Badge variant="outline" className="text-blue-600">
            {category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Status */}
        <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
          <div>
            <div className="text-sm text-gray-600">Current Value</div>
            <div className="text-2xl font-bold text-blue-600">
              {currentValue.toFixed(1)} {unit}
            </div>
          </div>
          {targetValue && (
            <div className="text-right">
              <div className="text-sm text-gray-600">Target</div>
              <div className="text-lg font-semibold text-purple-600">
                {targetValue.toFixed(1)} {unit}
              </div>
            </div>
          )}
        </div>

        {/* Impact Analysis */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            <span className="font-medium text-blue-800">ESG Impact Analysis</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-700">Environmental</span>
                <div className="flex items-center gap-1">
                  {getImpactIcon(environmentalImpact)}
                  <span className={`text-sm font-bold ${getImpactColor(environmentalImpact)}`}>
                    {environmentalImpact > 0 ? '+' : ''}{environmentalImpact.toFixed(2)}
                  </span>
                </div>
              </div>
              <Progress 
                value={Math.abs(environmentalImpact) * 20} 
                className="h-2 mt-2"
              />
            </div>

            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-blue-700">Social</span>
                <div className="flex items-center gap-1">
                  {getImpactIcon(socialImpact)}
                  <span className={`text-sm font-bold ${getImpactColor(socialImpact)}`}>
                    {socialImpact > 0 ? '+' : ''}{socialImpact.toFixed(2)}
                  </span>
                </div>
              </div>
              <Progress 
                value={Math.abs(socialImpact) * 20} 
                className="h-2 mt-2"
              />
            </div>

            <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-purple-700">Governance</span>
                <div className="flex items-center gap-1">
                  {getImpactIcon(governanceImpact)}
                  <span className={`text-sm font-bold ${getImpactColor(governanceImpact)}`}>
                    {governanceImpact > 0 ? '+' : ''}{governanceImpact.toFixed(2)}
                  </span>
                </div>
              </div>
              <Progress 
                value={Math.abs(governanceImpact) * 20} 
                className="h-2 mt-2"
              />
            </div>

            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Overall Impact</span>
                <div className="flex items-center gap-1">
                  {getImpactIcon(overallImpact)}
                  <span className={`text-sm font-bold ${getImpactColor(overallImpact)}`}>
                    {overallImpact > 0 ? '+' : ''}{overallImpact.toFixed(2)}
                  </span>
                </div>
              </div>
              <Progress 
                value={Math.abs(overallImpact) * 20} 
                className="h-2 mt-2"
              />
            </div>
          </div>
        </div>

        {/* Impact Weight */}
        <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-yellow-700">Impact Weight</span>
            <span className="text-lg font-bold text-yellow-600">
              {impactWeight.toFixed(1)}x
            </span>
          </div>
          <div className="text-xs text-yellow-600 mt-1">
            Higher weights indicate greater influence on ESG scores
          </div>
        </div>
      </CardContent>
    </Card>
  );
}