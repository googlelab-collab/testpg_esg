import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ESGParameter } from "@shared/schema";

interface ParameterSliderProps {
  parameter: ESGParameter;
  onUpdate?: (id: number, value: number) => void;
}

export function ParameterSlider({ parameter, onUpdate }: ParameterSliderProps) {
  const [value, setValue] = useState(parseFloat(parameter.currentValue));
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async (newValue: number) => {
      await apiRequest(`/api/esg-parameters/${parameter.id}`, {
        method: "PATCH",
        body: JSON.stringify({ currentValue: newValue.toString() }),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/esg-parameters"] });
      queryClient.invalidateQueries({ queryKey: ["/api/esg-scores"] });
      queryClient.invalidateQueries({ queryKey: [`/api/esg-parameters/${parameter.organizationId}`] });
      toast({
        title: "Parameter Updated",
        description: `${parameter.parameterName} has been updated successfully.`,
      });
      onUpdate?.(parameter.id, value);
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: "Failed to update parameter. Please try again.",
        variant: "destructive",
      });
      console.error("Parameter update error:", error);
    },
  });

  const handleValueChange = (newValue: number[]) => {
    setValue(newValue[0]);
  };

  const handleSave = () => {
    updateMutation.mutate(value);
  };

  const hasChanged = value !== parseFloat(parameter.currentValue);
  const targetValue = parameter.targetValue ? parseFloat(parameter.targetValue) : null;

  return (
    <Card className="esg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-gray-900">
            {parameter.parameterName}
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            {parameter.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-gray-500">Current Value</span>
            <span className="text-sm font-semibold text-primary">
              {value.toFixed(1)} {parameter.unit}
            </span>
          </div>
          
          <Slider
            value={[value]}
            onValueChange={handleValueChange}
            max={targetValue ? Math.max(100, targetValue * 1.2) : 100}
            min={0}
            step={0.1}
            className="w-full"
          />
          
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>0</span>
            {targetValue && (
              <span className="text-accent font-medium">
                Target: {targetValue} {parameter.unit}
              </span>
            )}
            <span>{targetValue ? Math.max(100, targetValue * 1.2) : 100}</span>
          </div>
        </div>

        {/* Impact Indicator */}
        <div className="p-3 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-600">ESG Impact Weight</span>
            <span className="font-medium">{parseFloat(parameter.impactWeight).toFixed(1)}x</span>
          </div>
          {targetValue && (
            <div className="mt-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-600">Progress to Target</span>
                <span className={`font-medium ${
                  value >= targetValue ? "text-success" : value >= targetValue * 0.8 ? "text-warning" : "text-error"
                }`}>
                  {((value / targetValue) * 100).toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div 
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    value >= targetValue ? "bg-success" : value >= targetValue * 0.8 ? "bg-warning" : "bg-error"
                  }`}
                  style={{ width: `${Math.min((value / targetValue) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        {hasChanged && (
          <Button
            onClick={handleSave}
            disabled={updateMutation.isPending}
            className="w-full esg-primary"
            size="sm"
          >
            {updateMutation.isPending ? "Updating..." : "Update Parameter"}
          </Button>
        )}

        {/* Data Source */}
        {parameter.source && (
          <div className="text-xs text-gray-500">
            Source: {parameter.source}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
