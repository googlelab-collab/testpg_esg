import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, AlertTriangle, XCircle, ExternalLink } from "lucide-react";
import type { ComplianceFramework } from "@shared/schema";

interface ComplianceStatusProps {
  frameworks: ComplianceFramework[];
  onUpdateFramework?: (id: number, updates: Partial<ComplianceFramework>) => void;
}

export function ComplianceStatus({ frameworks, onUpdateFramework }: ComplianceStatusProps) {
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "compliant":
        return <CheckCircle className="h-5 w-5 text-success" />;
      case "in_progress":
        return <Clock className="h-5 w-5 text-warning" />;
      case "non_compliant":
        return <XCircle className="h-5 w-5 text-error" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "compliant":
        return "status-compliant";
      case "in_progress":
        return "status-in-progress";
      case "non_compliant":
        return "status-non-compliant";
      default:
        return "status-pending";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "compliant":
        return "Compliant";
      case "in_progress":
        return "In Progress";
      case "non_compliant":
        return "Non-Compliant";
      default:
        return "Pending";
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "Not set";
    return new Date(date).toLocaleDateString();
  };

  const isOverdue = (deadline: Date | null) => {
    if (!deadline) return false;
    return new Date(deadline) < new Date();
  };

  return (
    <Card className="esg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5" />
          Regulatory Compliance Status
        </CardTitle>
        <p className="text-sm text-gray-600">
          Current compliance status across major ESG frameworks and regulations
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {frameworks.map((framework) => (
            <div
              key={framework.id}
              className="border rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  {getStatusIcon(framework.status)}
                  <h3 className="font-medium text-gray-900">{framework.frameworkName}</h3>
                </div>
                <Badge className={getStatusColor(framework.status)}>
                  {getStatusLabel(framework.status)}
                </Badge>
              </div>

              {/* Compliance Percentage */}
              {framework.compliancePercentage && (
                <div className="mb-3">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Compliance Progress</span>
                    <span className="font-medium">
                      {parseFloat(framework.compliancePercentage).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        parseFloat(framework.compliancePercentage) >= 90
                          ? "bg-success"
                          : parseFloat(framework.compliancePercentage) >= 70
                          ? "bg-warning"
                          : "bg-error"
                      }`}
                      style={{ width: `${framework.compliancePercentage}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Key Dates */}
              <div className="space-y-2 text-sm">
                {framework.lastAssessment && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Assessment:</span>
                    <span>{formatDate(framework.lastAssessment)}</span>
                  </div>
                )}
                {framework.nextDeadline && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Next Deadline:</span>
                    <span className={isOverdue(framework.nextDeadline) ? "text-error font-medium" : ""}>
                      {formatDate(framework.nextDeadline)}
                      {isOverdue(framework.nextDeadline) && " (Overdue)"}
                    </span>
                  </div>
                )}
              </div>

              {/* Requirements */}
              {framework.requirements && framework.requirements.length > 0 && (
                <div className="mt-3">
                  <h4 className="text-xs font-medium text-gray-600 mb-2">Key Requirements</h4>
                  <div className="space-y-1">
                    {framework.requirements.slice(0, 3).map((requirement, index) => (
                      <div key={index} className="text-xs text-gray-500 flex items-center gap-2">
                        <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                        {requirement}
                      </div>
                    ))}
                    {framework.requirements.length > 3 && (
                      <div className="text-xs text-gray-400">
                        +{framework.requirements.length - 3} more requirements
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="mt-4 flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  View Details
                </Button>
                {framework.status === "in_progress" && (
                  <Button size="sm" className="flex-1 esg-primary">
                    Update Status
                  </Button>
                )}
              </div>

              {/* Framework Links */}
              <div className="mt-3 pt-3 border-t">
                <Button variant="ghost" size="sm" className="text-xs text-gray-500 p-0 h-auto">
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View Official Framework
                </Button>
              </div>
            </div>
          ))}
        </div>

        {frameworks.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No compliance frameworks configured.</p>
            <Button className="mt-4 esg-primary">
              Configure Frameworks
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
