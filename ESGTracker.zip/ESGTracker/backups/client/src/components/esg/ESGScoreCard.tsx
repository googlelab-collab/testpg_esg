import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface ESGScoreCardProps {
  title: string;
  score: number;
  previousScore?: number;
  benchmark?: number;
  category: "environmental" | "social" | "governance" | "overall";
  className?: string;
}

export function ESGScoreCard({ 
  title, 
  score, 
  previousScore, 
  benchmark, 
  category, 
  className = "" 
}: ESGScoreCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "environmental":
        return "text-green-600";
      case "social":
        return "text-blue-600";
      case "governance":
        return "text-purple-600";
      case "overall":
        return "text-gray-900";
      default:
        return "text-gray-600";
    }
  };

  const getScoreGrade = (score: number) => {
    if (score >= 80) return { grade: "A", color: "bg-green-600" };
    if (score >= 70) return { grade: "B", color: "bg-blue-600" };
    if (score >= 60) return { grade: "C", color: "bg-yellow-600" };
    if (score >= 50) return { grade: "D", color: "bg-orange-600" };
    return { grade: "F", color: "bg-red-600" };
  };

  const getTrendIcon = () => {
    if (!previousScore) return null;
    const diff = score - previousScore;
    if (diff > 0) return <TrendingUp className="h-3 w-3 text-green-600" />;
    if (diff < 0) return <TrendingDown className="h-3 w-3 text-red-600" />;
    return <Minus className="h-3 w-3 text-gray-400" />;
  };

  const getTrendText = () => {
    if (!previousScore) return null;
    const diff = score - previousScore;
    if (diff > 0) return `+${diff.toFixed(1)} vs last period`;
    if (diff < 0) return `${diff.toFixed(1)} vs last period`;
    return "No change";
  };

  const getBenchmarkText = () => {
    if (!benchmark) return null;
    const diff = score - benchmark;
    if (diff > 0) return `+${diff.toFixed(1)} vs benchmark`;
    if (diff < 0) return `${diff.toFixed(1)} vs benchmark`;
    return "At benchmark";
  };

  const { grade, color } = getScoreGrade(score);

  return (
    <Card className={`esg-score-card ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <div className={`text-3xl font-bold ${getCategoryColor(category)}`}>
              {score.toFixed(1)}
            </div>
            {previousScore && (
              <div className="flex items-center space-x-1 text-sm mt-1">
                {getTrendIcon()}
                <span className={score > previousScore ? "text-green-600" : score < previousScore ? "text-red-600" : "text-gray-400"}>
                  {getTrendText()}
                </span>
              </div>
            )}
            {benchmark && (
              <div className="text-xs text-gray-500 mt-1">
                {getBenchmarkText()}
              </div>
            )}
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className={`w-12 h-12 ${color} rounded-full flex items-center justify-center`}>
              <span className="text-white font-bold text-lg">{grade}</span>
            </div>
            <Badge variant="outline" className="text-xs">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
