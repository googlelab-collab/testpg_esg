import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

interface ScoreCardProps {
  title: string;
  score: number;
  maxScore?: number;
  change?: number;
  changeLabel?: string;
  category: "environmental" | "social" | "governance" | "overall";
  icon?: React.ReactNode;
  grade?: string;
}

export function ScoreCard({
  title,
  score,
  maxScore = 100,
  change,
  changeLabel,
  category,
  icon,
  grade,
}: ScoreCardProps) {
  const getScoreColor = (category: string, score: number) => {
    if (score >= 80) return "text-success";
    if (score >= 60) return "text-warning";
    return "text-error";
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "environmental":
        return "text-primary";
      case "social":
        return "text-secondary";
      case "governance":
        return "text-purple-600";
      default:
        return "text-gray-900";
    }
  };

  const getBackgroundColor = (category: string) => {
    switch (category) {
      case "environmental":
        return "bg-primary/10";
      case "social":
        return "bg-secondary/10";
      case "governance":
        return "bg-purple-100";
      default:
        return "bg-gray-100";
    }
  };

  const getTrendIcon = () => {
    if (!change) return <Minus className="h-4 w-4" />;
    return change > 0 
      ? <TrendingUp className="h-4 w-4 text-success" />
      : <TrendingDown className="h-4 w-4 text-error" />;
  };

  const getTrendColor = () => {
    if (!change) return "text-gray-500";
    return change > 0 ? "text-success" : "text-error";
  };

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <p className={cn("text-3xl font-bold mt-1", getCategoryColor(category))}>
              {score}
            </p>
            {change !== undefined && (
              <div className={cn("flex items-center space-x-1 text-sm mt-1", getTrendColor())}>
                {getTrendIcon()}
                <span>
                  {change > 0 ? '+' : ''}{change} {changeLabel}
                </span>
              </div>
            )}
          </div>
          <div className="flex flex-col items-end space-y-2">
            {grade && (
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center",
                getBackgroundColor(category)
              )}>
                <span className={cn("font-bold", getCategoryColor(category))}>{grade}</span>
              </div>
            )}
            {icon && (
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center",
                getBackgroundColor(category)
              )}>
                {icon}
              </div>
            )}
          </div>
        </div>
        
        {/* Score progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Score Progress</span>
            <span>{score}/{maxScore}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={cn(
                "h-2 rounded-full transition-all duration-500",
                category === "environmental" && "bg-primary",
                category === "social" && "bg-secondary",
                category === "governance" && "bg-purple-600",
                category === "overall" && "bg-gray-700"
              )}
              style={{ width: `${(score / maxScore) * 100}%` }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
