import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { ESGScore } from "@shared/schema";

interface ESGScoreCardProps {
  title: string;
  score: number;
  category: "overall" | "environmental" | "social" | "governance";
  benchmark?: number;
  trend?: "up" | "down" | "stable";
  trendValue?: number;
  icon?: React.ReactNode;
  subtitle?: string;
}

export function ESGScoreCard({
  title,
  score,
  category,
  benchmark,
  trend,
  trendValue,
  icon,
  subtitle
}: ESGScoreCardProps) {
  
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-success";
    if (score >= 60) return "text-warning";
    return "text-error";
  };

  const getScoreGrade = (score: number) => {
    if (score >= 85) return "A";
    if (score >= 80) return "A-";
    if (score >= 75) return "B+";
    if (score >= 70) return "B";
    if (score >= 65) return "B-";
    if (score >= 60) return "C+";
    if (score >= 55) return "C";
    return "C-";
  };

  const getCategoryColors = (category: string) => {
    switch (category) {
      case "environmental":
        return {
          bg: "bg-primary/10",
          text: "text-primary",
          icon: "text-primary"
        };
      case "social":
        return {
          bg: "bg-secondary/10",
          text: "text-secondary",
          icon: "text-secondary"
        };
      case "governance":
        return {
          bg: "bg-purple-100",
          text: "text-purple-600",
          icon: "text-purple-600"
        };
      default:
        return {
          bg: "bg-gray-100",
          text: "text-gray-900",
          icon: "text-gray-600"
        };
    }
  };

  const colors = getCategoryColors(category);
  const grade = getScoreGrade(score);

  return (
    <Card className="esg-score-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <div className={`text-3xl font-bold ${colors.text} mt-1`}>
              {score.toFixed(0)}
            </div>
            
            {/* Trend Indicator */}
            {trend && trendValue && (
              <div className={`text-sm mt-1 flex items-center space-x-1 ${
                trend === "up" ? "text-success" : trend === "down" ? "text-error" : "text-gray-500"
              }`}>
                {trend === "up" && <TrendingUp className="h-3 w-3" />}
                {trend === "down" && <TrendingDown className="h-3 w-3" />}
                {trend === "stable" && <Minus className="h-3 w-3" />}
                <span>
                  {trend === "up" ? "+" : trend === "down" ? "-" : ""}
                  {Math.abs(trendValue).toFixed(1)}
                  {benchmark ? " vs benchmark" : " from last quarter"}
                </span>
              </div>
            )}

            {/* Benchmark Comparison */}
            {benchmark && (
              <div className="text-xs text-gray-500 mt-1">
                Benchmark: {benchmark.toFixed(0)} 
                <span className={`ml-1 ${score > benchmark ? "text-success" : "text-error"}`}>
                  ({score > benchmark ? "+" : ""}{(score - benchmark).toFixed(1)})
                </span>
              </div>
            )}
          </div>

          {/* Icon or Grade Badge */}
          <div className={`w-12 h-12 ${colors.bg} rounded-full flex items-center justify-center`}>
            {icon ? (
              <div className={colors.icon}>{icon}</div>
            ) : (
              <div className={`w-8 h-8 ${colors.text === "text-primary" ? "bg-primary" : colors.text === "text-secondary" ? "bg-secondary" : "bg-purple-600"} rounded-full flex items-center justify-center`}>
                <span className="text-white font-bold text-sm">{grade}</span>
              </div>
            )}
          </div>
        </div>

        {/* Score Range Indicator */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Poor</span>
            <span>Excellent</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-500 ${
                score >= 80 ? "bg-success" : score >= 60 ? "bg-warning" : "bg-error"
              }`}
              style={{ width: `${score}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>0</span>
            <span>50</span>
            <span>100</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
