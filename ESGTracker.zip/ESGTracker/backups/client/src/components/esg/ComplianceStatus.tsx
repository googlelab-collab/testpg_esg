import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, AlertCircle, XCircle } from "lucide-react";

interface ComplianceFramework {
  name: string;
  status: "compliant" | "in_progress" | "non_compliant" | "pending";
  lastAssessment?: string;
  nextDeadline?: string;
  description?: string;
}

interface ComplianceStatusProps {
  frameworks: ComplianceFramework[];
  className?: string;
}

export function ComplianceStatus({ frameworks, className = "" }: ComplianceStatusProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "compliant":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "in_progress":
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case "non_compliant":
        return <XCircle className="h-5 w-5 text-red-600" />;
      case "pending":
        return <AlertCircle className="h-5 w-5 text-gray-400" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "compliant":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Compliant</Badge>;
      case "in_progress":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">In Progress</Badge>;
      case "non_compliant":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Non-Compliant</Badge>;
      case "pending":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Pending</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <Card className={`esg-card ${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <CheckCircle className="h-5 w-5 text-primary" />
          <span>Regulatory Compliance Status</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {frameworks.map((framework, index) => (
            <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
              <div className="flex items-center space-x-3">
                {getStatusIcon(framework.status)}
                <div>
                  <div className="font-medium text-gray-900">{framework.name}</div>
                  {framework.description && (
                    <div className="text-sm text-gray-500">{framework.description}</div>
                  )}
                  {framework.nextDeadline && (
                    <div className="text-xs text-gray-400">
                      Next deadline: {framework.nextDeadline}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex flex-col items-end space-y-1">
                {getStatusBadge(framework.status)}
                {framework.lastAssessment && (
                  <div className="text-xs text-gray-400">
                    Last updated: {framework.lastAssessment}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
