import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import LoadingSpinner from "@/components/common/LoadingSpinner";

interface ParameterControlsProps {
  organizationId: number;
}

export default function ParameterControls({ organizationId }: ParameterControlsProps) {
  const [parameterValues, setParameterValues] = useState<{ [key: string]: number }>({});
  const [showImpact, setShowImpact] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: parameters, isLoading } = useQuery({
    queryKey: ["/api/esg-parameters", organizationId],
    onSuccess: (data) => {
      const initialValues = data.reduce((acc: any, param: any) => {
        acc[param.parameterName] = parseFloat(param.currentValue);
        return acc;
      }, {});
      setParameterValues(initialValues);
    },
  });

  const { data: impact, mutate: calculateImpact } = useMutation({
    mutationFn: async (changes: { [key: string]: number }) => {
      const response = await apiRequest("POST", "/api/calculate-parameter-impact", {
        organizationId,
        parameterChanges: changes,
      });
      return response.json();
    },
    onSuccess: () => {
      setShowImpact(true);
    },
  });

  const updateParameter = useMutation({
    mutationFn: async ({ id, value }: { id: number; value: number }) => {
      const response = await apiRequest("PUT", `/api/esg-parameters/${id}`, {
        currentValue: value.toString(),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["/api/esg-parameters", organizationId]);
      queryClient.invalidateQueries(["/api/esg-scores", organizationId, "latest"]);
      toast({
        title: "Parameter Updated",
        description: "ESG score recalculated successfully",
      });
    },
  });

  if (isLoading || !parameters) {
    return <LoadingSpinner />;
  }

  const handleParameterChange = (parameterName: string, value: number) => {
    setParameterValues(prev => ({
      ...prev,
      [parameterName]: value,
    }));
  };

  const handleCalculateImpact = () => {
    const changes = Object.keys(parameterValues).reduce((acc: any, key) => {
      const param = parameters.find((p: any) => p.parameterName === key);
      if (param && parameterValues[key] !== parseFloat(param.currentValue)) {
        acc[key] = parameterValues[key];
      }
      return acc;
    }, {});

    if (Object.keys(changes).length > 0) {
      calculateImpact(changes);
    }
  };

  const handleApplyChanges = () => {
    Object.keys(parameterValues).forEach(parameterName => {
      const param = parameters.find((p: any) => p.parameterName === parameterName);
      if (param && parameterValues[parameterName] !== parseFloat(param.currentValue)) {
        updateParameter.mutate({
          id: param.id,
          value: parameterValues[parameterName],
        });
      }
    });
  };

  const getParametersByCategory = (category: string) => {
    return parameters.filter((param: any) => param.category === category);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "environmental":
        return "text-primary";
      case "social":
        return "text-blue-600";
      case "governance":
        return "text-purple-600";
      default:
        return "text-gray-600";
    }
  };

  return (
    <Card className="esg-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Interactive ESG Score Parameters
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleCalculateImpact}>
              Calculate Impact
            </Button>
            <Button onClick={handleApplyChanges} disabled={updateParameter.isPending}>
              Apply Changes
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Environmental Parameters */}
          <div className="space-y-4">
            <h3 className={`font-medium ${getCategoryColor("environmental")}`}>
              Environmental Parameters
            </h3>
            <div className="space-y-4">
              {getParametersByCategory("environmental").map((param: any) => (
                <div key={param.id}>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-gray-700">
                      {param.parameterName.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </label>
                    <Badge variant="outline" className="text-xs">
                      {param.unit}
                    </Badge>
                  </div>
                  <Slider
                    value={[parameterValues[param.parameterName] || parseFloat(param.currentValue)]}
                    onValueChange={(value) => handleParameterChange(param.parameterName, value[0])}
                    max={param.unit === "%" ? 100 : 200}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0{param.unit}</span>
                    <span className="font-medium text-primary">
                      {parameterValues[param.parameterName] || parseFloat(param.currentValue)}{param.unit}
                    </span>
                    <span>{param.unit === "%" ? 100 : 200}{param.unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Social Parameters */}
          <div className="space-y-4">
            <h3 className={`font-medium ${getCategoryColor("social")}`}>
              Social Parameters
            </h3>
            <div className="space-y-4">
              {getParametersByCategory("social").map((param: any) => (
                <div key={param.id}>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-gray-700">
                      {param.parameterName.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </label>
                    <Badge variant="outline" className="text-xs">
                      {param.unit}
                    </Badge>
                  </div>
                  <Slider
                    value={[parameterValues[param.parameterName] || parseFloat(param.currentValue)]}
                    onValueChange={(value) => handleParameterChange(param.parameterName, value[0])}
                    max={param.unit === "%" ? 100 : 200}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0{param.unit}</span>
                    <span className="font-medium text-blue-600">
                      {parameterValues[param.parameterName] || parseFloat(param.currentValue)}{param.unit}
                    </span>
                    <span>{param.unit === "%" ? 100 : 200}{param.unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Governance Parameters */}
          <div className="space-y-4">
            <h3 className={`font-medium ${getCategoryColor("governance")}`}>
              Governance Parameters
            </h3>
            <div className="space-y-4">
              {getParametersByCategory("governance").map((param: any) => (
                <div key={param.id}>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-gray-700">
                      {param.parameterName.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </label>
                    <Badge variant="outline" className="text-xs">
                      {param.unit}
                    </Badge>
                  </div>
                  <Slider
                    value={[parameterValues[param.parameterName] || parseFloat(param.currentValue)]}
                    onValueChange={(value) => handleParameterChange(param.parameterName, value[0])}
                    max={param.unit === "%" ? 100 : 200}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0{param.unit}</span>
                    <span className="font-medium text-purple-600">
                      {parameterValues[param.parameterName] || parseFloat(param.currentValue)}{param.unit}
                    </span>
                    <span>{param.unit === "%" ? 100 : 200}{param.unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Real-time Impact Visualization */}
        {showImpact && impact && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Parameter Impact on Overall ESG Score
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {impact.environmentalImpact > 0 ? '+' : ''}{impact.environmentalImpact.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">Environmental</div>
                <div className={`text-xs ${impact.environmentalImpact > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {impact.environmentalImpact > 0 ? 'Improvement' : 'Decline'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {impact.socialImpact > 0 ? '+' : ''}{impact.socialImpact.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">Social</div>
                <div className={`text-xs ${impact.socialImpact > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {impact.socialImpact > 0 ? 'Improvement' : 'Decline'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {impact.governanceImpact > 0 ? '+' : ''}{impact.governanceImpact.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">Governance</div>
                <div className={`text-xs ${impact.governanceImpact > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {impact.governanceImpact > 0 ? 'Improvement' : 'Decline'}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
