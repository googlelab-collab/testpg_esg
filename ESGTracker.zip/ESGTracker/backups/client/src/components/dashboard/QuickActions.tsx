import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Upload, TrendingUp, Users, ChevronRight } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      icon: FileText,
      title: "Generate CSRD Report",
      description: "Create compliance report for EU Corporate Sustainability Reporting Directive",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      icon: Upload,
      title: "Upload Emissions Data",
      description: "Import latest GHG emissions data from facilities",
      color: "text-primary",
      bgColor: "bg-green-50",
    },
    {
      icon: TrendingUp,
      title: "Set New Targets",
      description: "Update ESG performance targets and KPIs",
      color: "text-amber-600",
      bgColor: "bg-amber-50",
    },
    {
      icon: Users,
      title: "Schedule Audit",
      description: "Book ESG audit with certified third-party assessor",
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
  ];

  return (
    <Card className="esg-card">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              className="w-full justify-between p-4 h-auto text-left hover:bg-gray-50"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${action.bgColor}`}>
                  <action.icon className={`h-5 w-5 ${action.color}`} />
                </div>
                <div>
                  <div className="font-medium text-gray-900">{action.title}</div>
                  <div className="text-sm text-gray-500">{action.description}</div>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
