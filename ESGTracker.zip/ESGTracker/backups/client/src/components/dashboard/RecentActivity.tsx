import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import LoadingSpinner from "@/components/common/LoadingSpinner";

interface RecentActivityProps {
  organizationId: number;
}

export default function RecentActivity({ organizationId }: RecentActivityProps) {
  const { data: activityLogs, isLoading } = useQuery({
    queryKey: ["/api/activity-log", organizationId],
    retry: false,
  });

  if (isLoading) {
    return <LoadingSpinner />;
  }

  const getActivityColor = (action: string) => {
    switch (action) {
      case "data_validation":
        return "bg-green-500";
      case "report_approval":
        return "bg-blue-500";
      case "reminder":
        return "bg-yellow-500";
      case "target_update":
        return "bg-primary";
      case "parameter_update":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  const getActivitySource = (action: string) => {
    switch (action) {
      case "data_validation":
        return "System";
      case "report_approval":
        return "Board of Directors";
      case "reminder":
        return "Supply Chain";
      case "target_update":
        return "Sustainability Team";
      case "parameter_update":
        return "ESG Manager";
      default:
        return "System";
    }
  };

  return (
    <Card className="esg-card">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activityLogs?.map((log: any) => (
            <div key={log.id} className="flex items-start space-x-3">
              <div className={`w-2 h-2 rounded-full mt-2 ${getActivityColor(log.action)}`} />
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">{log.description}</p>
                <p className="text-xs text-gray-500">
                  {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })} • {getActivitySource(log.action)}
                </p>
              </div>
            </div>
          ))}
        </div>
        <Button
          variant="ghost"
          className="w-full mt-4 text-center text-sm text-blue-600 hover:text-blue-700 font-medium"
        >
          View All Activity
        </Button>
      </CardContent>
    </Card>
  );
}
