import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';

export default function SimpleReportTest() {
  const generateSimpleReport = async () => {
    try {
      console.log('Testing simple report generation...');
      
      // Create PDF blob directly without dynamic imports
      const pdfBlob = await createTestPDF();
      
      if (pdfBlob) {
        // Use multiple download methods for better compatibility
        downloadPDFBlob(pdfBlob, 'ESG_Test_Report.pdf');
        console.log('Test PDF generated and download initiated');
        alert('Test PDF generated! Check your downloads folder.');
      } else {
        throw new Error('Failed to create PDF blob');
      }
      
    } catch (error) {
      console.error('Error generating test PDF:', error);
      alert('Error generating PDF: ' + error.message);
    }
  };

  const createTestPDF = async () => {
    try {
      // Dynamic import with proper error handling
      const jsPDFModule = await import('jspdf');
      const jsPDF = jsPDFModule.default || jsPDFModule.jsPDF;
      
      if (!jsPDF) {
        throw new Error('jsPDF not available');
      }
      
      console.log('jsPDF loaded, creating document...');
      const pdf = new jsPDF();
      
      // Add content
      pdf.setFontSize(20);
      pdf.text('ESG Report Test', 20, 20);
      
      pdf.setFontSize(12);
      pdf.text('This is a test of PDF generation functionality.', 20, 40);
      pdf.text('Generated at: ' + new Date().toLocaleString(), 20, 55);
      
      pdf.setFontSize(14);
      pdf.text('Sample ESG Metrics:', 20, 80);
      
      pdf.setFontSize(10);
      pdf.text('• GHG Emissions: 45,230 tCO2e (Target: 40,000 tCO2e)', 25, 95);
      pdf.text('• Renewable Energy: 45% (Target: 60%)', 25, 105);
      pdf.text('• Water Usage: 125,000 m³ (Target: 100,000 m³)', 25, 115);
      
      // Convert to blob
      const pdfOutput = pdf.output('blob');
      console.log('PDF blob created, size:', pdfOutput.size);
      return pdfOutput;
      
    } catch (error) {
      console.error('Error in createTestPDF:', error);
      return null;
    }
  };

  const downloadPDFBlob = (blob: Blob, filename: string) => {
    try {
      // Method 1: Create download link
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up URL object
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      
      console.log('Download initiated via blob URL');
      
    } catch (error) {
      console.error('Download failed:', error);
      
      // Method 2: Try direct blob download
      try {
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = reader.result as string;
          const link = document.createElement('a');
          link.href = dataUrl;
          link.download = filename;
          link.click();
        };
        reader.readAsDataURL(blob);
        console.log('Fallback download initiated via FileReader');
      } catch (fallbackError) {
        console.error('Fallback download also failed:', fallbackError);
      }
    }
  };

  return (
    <Button 
      onClick={generateSimpleReport}
      className="flex items-center gap-2"
    >
      <FileText className="h-4 w-4" />
      Test PDF Generation
    </Button>
  );
}