import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText, Loader2 } from 'lucide-react';

export default function QuickPDFTest() {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateQuickPDF = async () => {
    setIsGenerating(true);
    
    try {
      console.log('Starting quick PDF test...');
      
      // Import jsPDF directly from global if available, otherwise dynamic import
      let jsPDF;
      
      if (typeof window !== 'undefined' && (window as any).jspdf) {
        jsPDF = (window as any).jspdf.jsPDF;
        console.log('Using global jsPDF');
      } else {
        const jsPDFModule = await import('jspdf');
        jsPDF = jsPDFModule.default;
        console.log('Using imported jsPDF');
      }
      
      if (!jsPDF) {
        throw new Error('jsPDF library not available');
      }
      
      // Create PDF
      const doc = new jsPDF();
      
      // Add content
      doc.setFontSize(20);
      doc.text('ESG Report Test', 20, 30);
      
      doc.setFontSize(12);
      doc.text('Generated: ' + new Date().toLocaleString(), 20, 50);
      doc.text('This is a direct PDF generation test.', 20, 70);
      
      doc.setFontSize(14);
      doc.text('Sample Data:', 20, 90);
      doc.setFontSize(10);
      doc.text('• Total GHG Emissions: 45,230 tCO2e', 25, 105);
      doc.text('• Renewable Energy: 45%', 25, 115);
      doc.text('• Employee Safety Rate: 99.2%', 25, 125);
      
      // Convert to blob and download
      const pdfBlob = doc.output('blob');
      console.log('PDF blob created, size:', pdfBlob.size);
      
      // Download immediately
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Quick_ESG_Test.pdf';
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      console.log('Quick PDF downloaded successfully');
      alert('Quick PDF test successful! Check downloads.');
      
    } catch (error) {
      console.error('Quick PDF test failed:', error);
      alert('Quick PDF test failed: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Button 
      onClick={generateQuickPDF}
      disabled={isGenerating}
      variant="outline"
      className="flex items-center gap-2"
    >
      {isGenerating ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <FileText className="h-4 w-4" />
      )}
      {isGenerating ? 'Generating...' : 'Quick PDF Test'}
    </Button>
  );
}