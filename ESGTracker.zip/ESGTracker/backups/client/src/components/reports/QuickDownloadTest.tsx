import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export default function QuickDownloadTest() {
  const testDirectDownload = () => {
    try {
      console.log('Testing direct download without PDF generation...');
      
      // Create a simple text file to test download functionality
      const testContent = `ESG Test Report
Generated: ${new Date().toLocaleString()}

This is a test file to verify download functionality.

Sample ESG Data:
- GHG Emissions: 45,230 tCO2e
- Renewable Energy: 45%
- Water Usage: 125,000 m³
- Board Diversity: 40%

Test completed successfully!`;
      
      const blob = new Blob([testContent], { type: 'text/plain' });
      
      // Test download
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ESG_Test_File.txt';
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      console.log('Text file download initiated');
      alert('Test text file download initiated! Check your downloads.');
      
    } catch (error) {
      console.error('Download test failed:', error);
      alert('Download test failed: ' + error.message);
    }
  };

  return (
    <Button 
      onClick={testDirectDownload}
      variant="secondary"
      className="flex items-center gap-2"
    >
      <Download className="h-4 w-4" />
      Test Download
    </Button>
  );
}