import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Download, 
  Loader2, 
  CheckCircle, 
  Globe, 
  Building,
  Shield,
  Leaf,
  Users
} from 'lucide-react';
import { useReportGeneration, type ReportGenerationOptions } from '@/hooks/useReportGeneration';

interface ReportGeneratorProps {
  defaultModule?: string;
  defaultReportType?: 'environmental' | 'social' | 'governance' | 'comprehensive';
  onClose?: () => void;
}

export default function ReportGenerator({ 
  defaultModule = 'Comprehensive ESG',
  defaultReportType = 'comprehensive',
  onClose 
}: ReportGeneratorProps) {
  const { generateReport, isGenerating, frameworks } = useReportGeneration();
  
  const [options, setOptions] = useState<ReportGenerationOptions>({
    reportType: defaultReportType,
    module: defaultModule,
    period: 'Annual 2024',
    framework: 'GRI',
    includeCharts: true,
    includeMetrics: true,
    includeCompliance: true,
  });

  const reportTypes = [
    { value: 'environmental', label: 'Environmental', icon: Leaf, color: 'text-green-600' },
    { value: 'social', label: 'Social', icon: Users, color: 'text-blue-600' },
    { value: 'governance', label: 'Governance', icon: Shield, color: 'text-purple-600' },
    { value: 'comprehensive', label: 'Comprehensive ESG', icon: Globe, color: 'text-gray-600' },
  ];

  const periods = [
    'Annual 2024',
    'Q4 2024',
    'Q3 2024',
    'H1 2024',
    'Custom Period'
  ];

  const handleGenerate = async () => {
    try {
      await generateReport(options);
      if (onClose) onClose();
    } catch (error) {
      // Error handling is done in the hook
    }
  };

  const getFrameworkDescription = (framework: any) => {
    return framework?.description || 'Standard ESG reporting framework';
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <FileText className="h-6 w-6 text-blue-600" />
          ESG Report Generator
        </CardTitle>
        <p className="text-sm text-gray-600">
          Generate comprehensive ESG reports compliant with international standards
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Report Type Selection */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Report Type</Label>
          <div className="grid grid-cols-2 gap-3">
            {reportTypes.map((type) => {
              const IconComponent = type.icon;
              return (
                <div
                  key={type.value}
                  onClick={() => setOptions(prev => ({ ...prev, reportType: type.value as any }))}
                  className={`cursor-pointer border-2 rounded-lg p-4 transition-all hover:shadow-md ${
                    options.reportType === type.value 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComponent className={`h-5 w-5 ${type.color}`} />
                    <span className="font-medium">{type.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <Separator />

        {/* Framework Selection */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Reporting Framework</Label>
          <Select 
            value={options.framework} 
            onValueChange={(value) => setOptions(prev => ({ ...prev, framework: value as any }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select framework" />
            </SelectTrigger>
            <SelectContent>
              {frameworks.map((framework: any) => (
                <SelectItem key={framework.id} value={framework.id}>
                  <div className="flex items-center justify-between w-full">
                    <span>{framework.name}</span>
                    <Badge variant="outline" className="ml-2">
                      {framework.id}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {options.framework && (
            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
              {getFrameworkDescription(frameworks.find((f: any) => f.id === options.framework))}
            </div>
          )}
        </div>

        {/* Period Selection */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Reporting Period</Label>
          <Select 
            value={options.period} 
            onValueChange={(value) => setOptions(prev => ({ ...prev, period: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              {periods.map((period) => (
                <SelectItem key={period} value={period}>
                  {period}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Report Options */}
        <div className="space-y-4">
          <Label className="text-base font-semibold">Report Content</Label>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Checkbox
                id="includeMetrics"
                checked={options.includeMetrics}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeMetrics: !!checked }))
                }
              />
              <Label htmlFor="includeMetrics" className="flex-1">
                Include Performance Metrics
              </Label>
              <Badge variant="outline">Recommended</Badge>
            </div>
            
            <div className="flex items-center space-x-3">
              <Checkbox
                id="includeCompliance"
                checked={options.includeCompliance}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeCompliance: !!checked }))
                }
              />
              <Label htmlFor="includeCompliance" className="flex-1">
                Include Compliance Analysis
              </Label>
              <Badge variant="outline">Required</Badge>
            </div>
            
            <div className="flex items-center space-x-3">
              <Checkbox
                id="includeCharts"
                checked={options.includeCharts}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeCharts: !!checked }))
                }
              />
              <Label htmlFor="includeCharts" className="flex-1">
                Include Data Visualizations
              </Label>
            </div>
          </div>
        </div>

        <Separator />

        {/* Compliance Information */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-semibold text-green-800">Compliance Ready</span>
          </div>
          <p className="text-sm text-green-700">
            Generated reports meet requirements for regulatory submissions and stakeholder transparency.
          </p>
        </div>

        {/* Generate Button */}
        <div className="flex gap-3">
          <Button 
            onClick={handleGenerate}
            disabled={isGenerating}
            className="flex-1 h-12"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating Report...
              </>
            ) : (
              <>
                <Download className="h-4 w-4 mr-2" />
                Generate & Download Report
              </>
            )}
          </Button>
          
          {onClose && (
            <Button variant="outline" onClick={onClose} disabled={isGenerating}>
              Cancel
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}