import { Link, useLocation } from "wouter";
import {
  Gauge,
  Leaf,
  Zap,
  Droplets,
  Recycle,
  Wind,
  Flower,
  Sun,
  Users,
  HardHat,
  Heart,
  Building,
  Scale,
  GraduationCap,
  Shield,
  Crown,
  DollarSign,
  ShieldCheck,
  Gavel,
  MessageSquare,
  AlertTriangle,
  ClipboardCheck,
} from "lucide-react";

interface NavItem {
  name: string;
  path: string;
  icon: any;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navigationSections: NavSection[] = [
  {
    title: "Dashboard",
    items: [
      { name: "Executive Dashboard", path: "/", icon: Gauge },
    ],
  },
  {
    title: "Environmental",
    items: [
      { name: "GHG Emissions", path: "/environmental/ghg-emissions", icon: Leaf },
      { name: "Energy Analytics", path: "/environmental/energy-analytics", icon: Zap },
      { name: "Water Management", path: "/environmental/water-management", icon: Droplets },
      { name: "Circular Economy", path: "/environmental/waste-circular", icon: Recycle },
      { name: "Air Quality", path: "/environmental/air-quality", icon: Wind },
      { name: "Biodiversity", path: "/environmental/biodiversity", icon: Flower },
      { name: "Renewable Energy", path: "/environmental/renewable-energy", icon: Sun },
    ],
  },
  {
    title: "Social",
    items: [
      { name: "Workforce Diversity", path: "/social/workforce-diversity", icon: Users },
      { name: "Employee Safety", path: "/social/employee-safety", icon: HardHat },
      { name: "Community Impact", path: "/social/community-impact", icon: Heart },
      { name: "Supply Chain Labor", path: "/social/supply-chain-labor", icon: Building },
      { name: "Human Rights", path: "/social/human-rights", icon: Scale },
      { name: "Employee Wellbeing", path: "/social/employee-wellbeing", icon: Heart },
      { name: "Skills Development", path: "/social/skills-development", icon: GraduationCap },
    ],
  },
  {
    title: "Governance",
    items: [
      { name: "Board Composition", path: "/governance/board-composition", icon: Crown },
      { name: "Executive Compensation", path: "/governance/executive-compensation", icon: DollarSign },
      { name: "Cybersecurity", path: "/governance/cybersecurity", icon: ShieldCheck },
      { name: "Ethics & Anti-Corruption", path: "/governance/ethics-anti-corruption", icon: Gavel },
      { name: "Stakeholder Engagement", path: "/governance/stakeholder-engagement", icon: MessageSquare },
      { name: "Risk Management", path: "/governance/risk-management", icon: AlertTriangle },
      { name: "Regulatory Compliance", path: "/governance/regulatory-compliance", icon: ClipboardCheck },
    ],
  },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-64 bg-white h-screen fixed left-0 border-r border-gray-200 overflow-y-auto scrollbar-thin">
      <div className="p-6">
        {navigationSections.map((section) => (
          <div key={section.title} className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              {section.title}
            </h3>
            <nav className="space-y-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={
                      isActive
                        ? "esg-nav-item-active"
                        : "esg-nav-item"
                    }
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        ))}
      </div>
    </aside>
  );
}
