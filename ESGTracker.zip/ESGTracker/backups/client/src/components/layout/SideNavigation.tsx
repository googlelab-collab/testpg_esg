import { Link, useLocation } from "wouter";
import { 
  Gauge, 
  Zap, 
  Droplets, 
  Recycle, 
  Wind, 
  Leaf, 
  Sun, 
  Users, 
  HardHat, 
  HandHeart, 
  Factory, 
  Scale, 
  Heart, 
  GraduationCap, 
  Crown, 
  DollarSign, 
  Shield, 
  Gavel, 
  MessageSquare, 
  AlertTriangle, 
  ClipboardCheck,
  Haze
} from "lucide-react";

interface NavItem {
  name: string;
  href: string;
  icon: any;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navigationSections: NavSection[] = [
  {
    title: "Environmental",
    items: [
      { name: "GHG Emissions", href: "/environmental/ghg-emissions", icon: Haze },
      { name: "Energy Analytics", href: "/environmental/energy-analytics", icon: Zap },
      { name: "Water Management", href: "/environmental/water-management", icon: Droplets },
      { name: "Circular Economy", href: "/environmental/circular-economy", icon: Recycle },
      { name: "Air Quality", href: "/environmental/air-quality", icon: Wind },
      { name: "Biodiversity", href: "/environmental/biodiversity", icon: Leaf },
      { name: "Renewable Energy", href: "/environmental/renewable-energy", icon: Sun },
    ]
  },
  {
    title: "Social",
    items: [
      { name: "Workforce Diversity", href: "/social/workforce-diversity", icon: Users },
      { name: "Employee Safety", href: "/social/employee-safety", icon: HardHat },
      { name: "Community Impact", href: "/social/community-impact", icon: HandHeart },
      { name: "Supply Chain Labor", href: "/social/supply-chain-labor", icon: Factory },
      { name: "Human Rights", href: "/social/human-rights", icon: Scale },
      { name: "Employee Wellbeing", href: "/social/employee-wellbeing", icon: Heart },
      { name: "Skills Development", href: "/social/skills-development", icon: GraduationCap },
    ]
  },
  {
    title: "Governance",
    items: [
      { name: "Board Composition", href: "/governance/board-composition", icon: Crown },
      { name: "Executive Compensation", href: "/governance/executive-compensation", icon: DollarSign },
      { name: "Cybersecurity", href: "/governance/cybersecurity", icon: Shield },
      { name: "Ethics & Anti-Corruption", href: "/governance/ethics-anti-corruption", icon: Gavel },
      { name: "Stakeholder Engagement", href: "/governance/stakeholder-engagement", icon: MessageSquare },
      { name: "Risk Management", href: "/governance/risk-management", icon: AlertTriangle },
      { name: "Regulatory Compliance", href: "/governance/regulatory-compliance", icon: ClipboardCheck },
    ]
  }
];

export default function SideNavigation() {
  const location = useLocation();
  
  return (
    <aside className="w-64 bg-white h-screen fixed left-0 border-r border-gray-200 overflow-y-auto">
      <div className="p-6">
        {/* Executive Dashboard */}
        <div className="mb-6">
          <Link
            to="/"
            className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
              location.pathname === "/" 
                ? "text-green-600 bg-green-50 font-medium" 
                : "text-gray-700 hover:text-green-600 hover:bg-green-50"
            }`}
          >
            <Gauge className="h-5 w-5" />
            <span>Executive Dashboard</span>
          </Link>
        </div>

        {/* Navigation Sections */}
        {navigationSections.map((section) => (
          <div key={section.title} className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              {section.title}
            </h3>
            <nav className="space-y-1">
              {section.items.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                    location.pathname === item.href
                      ? "text-green-600 bg-green-50 font-medium"
                      : "text-gray-700 hover:text-green-600 hover:bg-green-50"
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              ))}
            </nav>
          </div>
        ))}
      </div>
    </aside>
  );
}
