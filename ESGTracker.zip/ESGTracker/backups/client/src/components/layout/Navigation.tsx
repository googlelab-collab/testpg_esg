import { Search, Bell, Leaf, LogOut, User, Menu, Users, Settings, Shield, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { getUserRoleDescription } from "@shared/roles";
import { useState } from "react";
import { Link } from "wouter";
import logo from "@/assets/logo.svg";

function getRoleEmoji(role: string): string {
  const roleInfo = getUserRoleDescription(role as any);
  return roleInfo?.emoji || '👤';
}

function getRoleName(role: string): string {
  const roleInfo = getUserRoleDescription(role as any);
  return roleInfo?.name || 'User';
}

export default function Navigation() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showAdminMenu, setShowAdminMenu] = useState(false);

  const handleLogout = async () => {
    try {
      if (user?.id === "admin") {
        // Admin logout
        await fetch("/api/auth/admin-logout", { method: "POST" });
      } else {
        // Regular Replit logout
        window.location.href = "/api/logout";
        return;
      }
      
      toast({
        title: "Logged out successfully",
        description: "You have been signed out.",
      });
      
      // Reload to trigger auth state update
      window.location.reload();
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error signing out.",
        variant: "destructive",
      });
    }
  };

  return (
    <nav className="bg-white border-b border-gray-200 fixed w-full top-0 z-50">
      <div className="max-w-full px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <img src={logo} alt="ESGuite Logo" className="h-14 w-auto" />
            </div>
            <Badge variant="outline" className="text-xs">
              Enterprise Platform
            </Badge>
          </div>
          
          <div className="flex items-center space-x-6">
            {/* Global Search */}
            <div className="relative">
              <input
                type="text"
                placeholder="Search ESG data, reports..."
                className="w-80 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-esg-primary focus:border-transparent"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            </div>
            
            {/* Notifications */}
            <div className="relative">
              <button className="text-gray-600 hover:text-esg-primary">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  3
                </span>
              </button>
            </div>
            
            {/* Admin Menu */}
            {(user?.role === 'admin' || user?.id === 'admin' || user?.email === 'vrindaa.grg@gmail.com') && (
              <div className="relative">
                <Button
                  onClick={() => setShowAdminMenu(!showAdminMenu)}
                  variant="ghost"
                  size="sm"
                  className="text-gray-600 hover:text-esg-primary"
                >
                  <Menu className="h-5 w-5" />
                </Button>
                
                {showAdminMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                    <div className="p-2">
                      <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-2">
                        Administration
                      </div>
                      <Link to="/admin/users">
                        <button 
                          onClick={() => setShowAdminMenu(false)}
                          className="flex items-center w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                          <Users className="h-4 w-4 mr-3" />
                          User Management
                        </button>
                      </Link>
                      <Link to="/admin/roles">
                        <button 
                          onClick={() => setShowAdminMenu(false)}
                          className="flex items-center w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                          <Shield className="h-4 w-4 mr-3" />
                          Roles & Permissions
                        </button>
                      </Link>
                      <Link to="/admin/system">
                        <button 
                          onClick={() => setShowAdminMenu(false)}
                          className="flex items-center w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                          <Settings className="h-4 w-4 mr-3" />
                          System Settings
                        </button>
                      </Link>
                      <Link to="/admin/database">
                        <button 
                          onClick={() => setShowAdminMenu(false)}
                          className="flex items-center w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                          <Database className="h-4 w-4 mr-3" />
                          Database Console
                        </button>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* User Profile */}
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900 flex items-center gap-2">
                  {getRoleEmoji(user?.role || 'operations')}
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user?.email || "User"
                  }
                </div>
                <div className="text-xs text-gray-500">
                  {getRoleName(user?.role || 'operations')}
                </div>
              </div>
              
              {user?.profileImageUrl ? (
                <img
                  src={user.profileImageUrl}
                  alt="User profile"
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-5 w-5 text-gray-500" />
                </div>
              )}
              
              <Button
                onClick={handleLogout}
                variant="ghost"
                size="sm"
                className="text-gray-500 hover:text-red-600"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
