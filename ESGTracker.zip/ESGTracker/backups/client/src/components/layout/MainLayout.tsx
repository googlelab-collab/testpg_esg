import { ReactNode } from "react";
import TopNavigation from "./TopNavigation";
import SideNavigation from "./SideNavigation";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <TopNavigation />
      <div className="flex pt-20">
        <SideNavigation />
        <main className="flex-1 ml-64 p-6">
          {children}
        </main>
      </div>
      
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button 
          size="lg" 
          className="w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-105 esg-primary"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
