import { useState } from "react";
import { Bell, Search, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function TopNavigation() {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock user data - in production, this would come from auth context
  const currentUser = {
    name: "Sarah Chen",
    role: "ESG Manager",
    profileImageUrl: "https://pixabay.com/get/gc17631a56f6900269a96afc9b5a551568a0f27b7bd6a962757cfd0e61ff68e1b1ca43577f3a6938621efcdd20871e7037f887d4ad6ebb92a7694706f3e1c2f77_1280.jpg"
  };
  
  return (
    <nav className="bg-white border-b border-gray-200 fixed w-full top-0 z-50">
      <div className="max-w-full px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <Leaf className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">ESGuite</span>
            </div>
            <Badge variant="outline" className="text-xs">
              Enterprise Platform
            </Badge>
          </div>
          
          <div className="flex items-center space-x-6">
            {/* Global Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search ESG data, reports..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-80 pl-10"
              />
            </div>
            
            {/* Notifications */}
            <div className="relative">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs"
                >
                  3
                </Badge>
              </Button>
            </div>
            
            {/* User Profile */}
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900">{currentUser.name}</div>
                <div className="text-xs text-gray-500">{currentUser.role}</div>
              </div>
              <img 
                src={currentUser.profileImageUrl} 
                alt="User profile" 
                className="w-10 h-10 rounded-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
