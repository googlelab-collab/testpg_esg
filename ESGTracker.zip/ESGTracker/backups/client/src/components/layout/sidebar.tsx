import { Link, useLocation } from "wouter";
import {
  BarChart3, Leaf, Users, Shield, Zap, Droplet, 
  Recycle, Wind, Sprout, Sun, HardHat, Heart,
  GraduationCap, HandHeart, Scale, Crown, DollarSign,
  ShieldCheck, Gavel, MessageSquare, AlertTriangle,
  ClipboardCheck
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  userRole?: string;
}

interface NavigationItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  path: string;
  category?: string;
  requiredRoles?: string[];
}

export function Sidebar({ userRole = "ESG Manager" }: SidebarProps) {
  const [location] = useLocation();

  const navigationItems: NavigationItem[] = [
    // Dashboard
    {
      id: "dashboard",
      label: "Executive Dashboard",
      icon: BarChart3,
      path: "/",
    },
    
    // Environmental Section
    {
      id: "ghg",
      label: "GHG Emissions",
      icon: Leaf,
      path: "/environmental/ghg-emissions",
      category: "Environmental",
    },
    {
      id: "energy",
      label: "Energy Analytics",
      icon: Zap,
      path: "/environmental/energy-analytics",
      category: "Environmental",
    },
    {
      id: "water",
      label: "Water Management",
      icon: Droplet,
      path: "/environmental/water-management",
      category: "Environmental",
    },
    {
      id: "waste",
      label: "Circular Economy",
      icon: Recycle,
      path: "/environmental/waste-circular",
      category: "Environmental",
    },
    {
      id: "air",
      label: "Air Quality",
      icon: Wind,
      path: "/environmental/air-quality",
      category: "Environmental",
    },
    {
      id: "biodiversity",
      label: "Biodiversity",
      icon: Sprout,
      path: "/environmental/biodiversity",
      category: "Environmental",
    },
    {
      id: "renewable",
      label: "Renewable Energy",
      icon: Sun,
      path: "/environmental/renewable-energy",
      category: "Environmental",
    },
    
    // Social Section
    {
      id: "diversity",
      label: "Workforce Diversity",
      icon: Users,
      path: "/social/diversity",
      category: "Social",
    },
    {
      id: "safety",
      label: "Employee Safety",
      icon: HardHat,
      path: "/social/safety",
      category: "Social",
    },
    {
      id: "community",
      label: "Community Impact",
      icon: HandHeart,
      path: "/social/community",
      category: "Social",
    },
    {
      id: "supply-labor",
      label: "Supply Chain Labor",
      icon: Users,
      path: "/social/supply-labor",
      category: "Social",
    },
    {
      id: "human-rights",
      label: "Human Rights",
      icon: Scale,
      path: "/social/human-rights",
      category: "Social",
    },
    {
      id: "wellbeing",
      label: "Employee Wellbeing",
      icon: Heart,
      path: "/social/wellbeing",
      category: "Social",
    },
    {
      id: "skills",
      label: "Skills Development",
      icon: GraduationCap,
      path: "/social/skills",
      category: "Social",
    },
    
    // Governance Section
    {
      id: "board",
      label: "Board Composition",
      icon: Crown,
      path: "/governance/board",
      category: "Governance",
    },
    {
      id: "compensation",
      label: "Executive Compensation",
      icon: DollarSign,
      path: "/governance/compensation",
      category: "Governance",
    },
    {
      id: "cybersecurity",
      label: "Cybersecurity",
      icon: ShieldCheck,
      path: "/governance/cybersecurity",
      category: "Governance",
    },
    {
      id: "ethics",
      label: "Ethics & Anti-Corruption",
      icon: Gavel,
      path: "/governance/ethics",
      category: "Governance",
    },
    {
      id: "stakeholder",
      label: "Stakeholder Engagement",
      icon: MessageSquare,
      path: "/governance/stakeholder",
      category: "Governance",
    },
    {
      id: "risk",
      label: "Risk Management",
      icon: AlertTriangle,
      path: "/governance/risk",
      category: "Governance",
    },
    {
      id: "compliance",
      label: "Regulatory Compliance",
      icon: ClipboardCheck,
      path: "/governance/compliance",
      category: "Governance",
    },
  ];

  const groupedItems = navigationItems.reduce((acc, item) => {
    const category = item.category || "Dashboard";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {} as Record<string, NavigationItem[]>);

  const isActive = (path: string) => {
    return location === path || (path !== "/" && location.startsWith(path));
  };

  return (
    <aside className="w-64 bg-white h-screen fixed left-0 border-r border-gray-200 overflow-y-auto">
      <div className="p-6">
        {/* Dashboard */}
        {groupedItems.Dashboard && (
          <div className="mb-6">
            {groupedItems.Dashboard.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.id} href={item.path}>
                  <div
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                      isActive(item.path)
                        ? "text-primary bg-primary/10"
                        : "text-gray-700 hover:text-primary hover:bg-primary/5"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        {/* Environmental Section */}
        {groupedItems.Environmental && (
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Environmental
            </h3>
            <nav className="space-y-1">
              {groupedItems.Environmental.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.id} href={item.path}>
                    <div
                      className={cn(
                        "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                        isActive(item.path)
                          ? "text-primary bg-primary/10"
                          : "text-gray-700 hover:text-primary hover:bg-primary/5"
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}

        {/* Social Section */}
        {groupedItems.Social && (
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Social
            </h3>
            <nav className="space-y-1">
              {groupedItems.Social.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.id} href={item.path}>
                    <div
                      className={cn(
                        "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                        isActive(item.path)
                          ? "text-primary bg-primary/10"
                          : "text-gray-700 hover:text-primary hover:bg-primary/5"
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}

        {/* Governance Section */}
        {groupedItems.Governance && (
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Governance
            </h3>
            <nav className="space-y-1">
              {groupedItems.Governance.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.id} href={item.path}>
                    <div
                      className={cn(
                        "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                        isActive(item.path)
                          ? "text-primary bg-primary/10"
                          : "text-gray-700 hover:text-primary hover:bg-primary/5"
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}
      </div>
    </aside>
  );
}
