import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/layout/Navigation";
import Sidebar from "@/components/layout/Sidebar";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import Home from "@/pages/Home";
import Dashboard from "@/pages/Dashboard";
import GHGEmissions from "@/pages/environmental/ghg-emissions";
import EnergyAnalytics from "@/pages/environmental/energy-analytics";
import WaterManagement from "@/pages/environmental/water-management";
import WasteCircular from "@/pages/environmental/waste-circular";
import AirQuality from "@/pages/environmental/air-quality";
import Biodiversity from "@/pages/environmental/biodiversity";
import RenewableEnergy from "@/pages/environmental/renewable-energy";
import WorkforceDiversity from "@/pages/social/workforce-diversity";
import EmployeeSafety from "@/pages/social/employee-safety";
import CommunityImpact from "@/pages/social/community-impact";
import SupplyChainLabor from "@/pages/social/supply-chain-labor";
import HumanRights from "@/pages/social/human-rights";
import EmployeeWellbeing from "@/pages/social/employee-wellbeing";
import SkillsDevelopment from "@/pages/social/skills-development";
import BoardComposition from "@/pages/governance/BoardComposition";
import ExecutiveCompensation from "@/pages/governance/ExecutiveCompensation";
import Cybersecurity from "@/pages/governance/Cybersecurity";
import EthicsAntiCorruption from "@/pages/governance/EthicsAntiCorruption";
import StakeholderEngagement from "@/pages/governance/StakeholderEngagement";
import RiskManagement from "@/pages/governance/RiskManagement";
import RegulatoryCompliance from "@/pages/governance/RegulatoryCompliance";
import UserManagement from "@/pages/UserManagement";
import RolesPermissions from "@/pages/admin/RolesPermissions";
import SystemSettings from "@/pages/admin/SystemSettings";
import DatabaseConsole from "@/pages/admin/DatabaseConsole";


function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/" component={Landing} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => <AuthenticatedLayout><Home /></AuthenticatedLayout>} />
      <Route path="/dashboard" component={() => <AuthenticatedLayout><Dashboard /></AuthenticatedLayout>} />
          
      {/* Environmental Routes */}
      <Route path="/environmental/ghg-emissions" component={() => <AuthenticatedLayout><GHGEmissions /></AuthenticatedLayout>} />
      <Route path="/environmental/energy-analytics" component={() => <AuthenticatedLayout><EnergyAnalytics /></AuthenticatedLayout>} />
      <Route path="/environmental/water-management" component={() => <AuthenticatedLayout><WaterManagement /></AuthenticatedLayout>} />
      <Route path="/environmental/waste-circular" component={() => <AuthenticatedLayout><WasteCircular /></AuthenticatedLayout>} />
      <Route path="/environmental/air-quality" component={() => <AuthenticatedLayout><AirQuality /></AuthenticatedLayout>} />
      <Route path="/environmental/biodiversity" component={() => <AuthenticatedLayout><Biodiversity /></AuthenticatedLayout>} />
      <Route path="/environmental/renewable-energy" component={() => <AuthenticatedLayout><RenewableEnergy /></AuthenticatedLayout>} />
      
      {/* Social Routes */}
      <Route path="/social/workforce-diversity" component={() => <AuthenticatedLayout><WorkforceDiversity /></AuthenticatedLayout>} />
      <Route path="/social/employee-safety" component={() => <AuthenticatedLayout><EmployeeSafety /></AuthenticatedLayout>} />
      <Route path="/social/community-impact" component={() => <AuthenticatedLayout><CommunityImpact /></AuthenticatedLayout>} />
      <Route path="/social/supply-chain-labor" component={() => <AuthenticatedLayout><SupplyChainLabor /></AuthenticatedLayout>} />
      <Route path="/social/human-rights" component={() => <AuthenticatedLayout><HumanRights /></AuthenticatedLayout>} />
      <Route path="/social/employee-wellbeing" component={() => <AuthenticatedLayout><EmployeeWellbeing /></AuthenticatedLayout>} />
      <Route path="/social/skills-development" component={() => <AuthenticatedLayout><SkillsDevelopment /></AuthenticatedLayout>} />
      
      {/* Governance Routes */}
      <Route path="/governance/board-composition" component={() => <AuthenticatedLayout><BoardComposition /></AuthenticatedLayout>} />
      <Route path="/governance/executive-compensation" component={() => <AuthenticatedLayout><ExecutiveCompensation /></AuthenticatedLayout>} />
      <Route path="/governance/cybersecurity" component={() => <AuthenticatedLayout><Cybersecurity /></AuthenticatedLayout>} />
      <Route path="/governance/ethics-anti-corruption" component={() => <AuthenticatedLayout><EthicsAntiCorruption /></AuthenticatedLayout>} />
      <Route path="/governance/stakeholder-engagement" component={() => <AuthenticatedLayout><StakeholderEngagement /></AuthenticatedLayout>} />
      <Route path="/governance/risk-management" component={() => <AuthenticatedLayout><RiskManagement /></AuthenticatedLayout>} />
      <Route path="/governance/regulatory-compliance" component={() => <AuthenticatedLayout><RegulatoryCompliance /></AuthenticatedLayout>} />
      
      {/* Admin Routes */}
      <Route path="/admin/users" component={() => <AuthenticatedLayout><UserManagement /></AuthenticatedLayout>} />
      <Route path="/admin/roles" component={() => <AuthenticatedLayout><RolesPermissions /></AuthenticatedLayout>} />
      <Route path="/admin/system" component={() => <AuthenticatedLayout><SystemSettings /></AuthenticatedLayout>} />
      <Route path="/admin/database" component={() => <AuthenticatedLayout><DatabaseConsole /></AuthenticatedLayout>} />

    </Switch>
  );
}

function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="flex pt-20">
        <Sidebar />
        <main className="flex-1 ml-64 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}
