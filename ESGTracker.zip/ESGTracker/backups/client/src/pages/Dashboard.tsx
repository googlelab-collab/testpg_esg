import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import LoadingSpinner from "@/components/common/LoadingSpinner";
import ErrorMessage from "@/components/common/ErrorMessage";
import ReportGenerator from "@/components/reports/ReportGenerator";
import {
  TrendingUp,
  Download,
  Plus,
  Leaf,
  Users,
  Shield,
  CheckCircle,
  Clock,
  FileText,
  Upload,
  BarChart3,
  UserCheck,
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react";

const organizationId = 1;

export default function Dashboard() {
  const [showReportGenerator, setShowReportGenerator] = useState(false);
  const [parameters, setParameters] = useState({
    renewableEnergy: 45,
    emissionsReduction: 30,
    boardDiversity: 40,
    safetyTraining: 32,
    independentDirectors: 75,
    esgCompensation: 25,
  });

  const { data: esgScore, isLoading: scoresLoading, error: scoresError } = useQuery({
    queryKey: [`/api/esg-scores/${organizationId}`],
    retry: false,
  });

  const { data: complianceFrameworks, isLoading: complianceLoading, error: complianceError } = useQuery({
    queryKey: [`/api/compliance-frameworks/${organizationId}`],
    retry: false,
  });

  const { data: environmentalMetrics, isLoading: envLoading, error: envError } = useQuery({
    queryKey: [`/api/environmental-metrics/${organizationId}`],
    retry: false,
  });

  if (scoresLoading || complianceLoading || envLoading) return <LoadingSpinner />;
  
  // Debug logging
  console.log('Dashboard errors:', { scoresError, complianceError, envError });
  console.log('Dashboard data:', { esgScore, complianceFrameworks, environmentalMetrics });
  
  if (scoresError || complianceError || envError) {
    console.error('Failed to load dashboard data:', {
      scoresError: scoresError?.message,
      complianceError: complianceError?.message,
      envError: envError?.message
    });
    return <ErrorMessage message={`Failed to load dashboard data: ${scoresError?.message || complianceError?.message || envError?.message}`} />;
  }

  const handleParameterChange = (parameter: string, value: number) => {
    setParameters(prev => ({ ...prev, [parameter]: value }));
  };

  const getComplianceStatus = (status: string) => {
    switch (status) {
      case "compliant":
        return { icon: CheckCircle, text: "Compliant", color: "text-green-600" };
      case "in_progress":
        return { icon: Clock, text: "In Progress", color: "text-yellow-600" };
      default:
        return { icon: Clock, text: "Pending", color: "text-gray-600" };
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <ArrowUp className="h-4 w-4 text-green-600" />;
      case "down":
        return <ArrowDown className="h-4 w-4 text-red-600" />;
      default:
        return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Executive Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Real-time ESG performance overview and regulatory compliance status
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => setShowReportGenerator(true)}
          >
            <Download className="h-4 w-4" />
            Generate Report
          </Button>
          <Button className="flex items-center gap-2 esg-primary">
            <Plus className="h-4 w-4" />
            Add Module
          </Button>
        </div>
      </div>

      {/* PDF Test Section - Very Prominent */}
      <div className="bg-red-50 border-2 border-red-500 rounded-lg p-6 text-center">
        <h2 className="text-2xl font-bold text-red-800 mb-4">🔴 PDF Generation Test</h2>
        <button 
          className="bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-lg text-xl shadow-lg"
          onClick={async () => {
            try {
              alert('Starting PDF test...');
              console.log('PDF test button clicked');
              
              // Step 1: Text download test
              const content = `ESG Report Test\nGenerated: ${new Date().toLocaleString()}\n\nSample Data:\n- GHG Emissions: 45,230 tCO2e\n- Renewable Energy: 45%\n- Employee Safety: 99.2%`;
              const textBlob = new Blob([content], { type: 'text/plain' });
              const textUrl = URL.createObjectURL(textBlob);
              const textLink = document.createElement('a');
              textLink.href = textUrl;
              textLink.download = 'ESG_Test.txt';
              document.body.appendChild(textLink);
              textLink.click();
              document.body.removeChild(textLink);
              URL.revokeObjectURL(textUrl);
              
              alert('Text file downloaded! Now trying PDF...');
              
              // Step 2: PDF generation test
              const jsPDFModule = await import('jspdf');
              const jsPDF = jsPDFModule.default;
              const pdf = new jsPDF();
              
              pdf.setFontSize(20);
              pdf.text('ESG TEST REPORT', 20, 30);
              pdf.setFontSize(12);
              pdf.text('Generated: ' + new Date().toLocaleString(), 20, 50);
              pdf.text('Sample ESG Metrics:', 20, 70);
              pdf.text('• GHG Emissions: 45,230 tCO2e', 30, 90);
              pdf.text('• Renewable Energy: 45%', 30, 110);
              pdf.text('• Employee Safety Rate: 99.2%', 30, 130);
              
              pdf.save('ESG_Test_Report.pdf');
              
              alert('SUCCESS! PDF downloaded. Check your downloads folder.');
            } catch (error) {
              console.error('Error:', error);
              alert('ERROR: ' + error.message);
            }
          }}
        >
          CLICK HERE TO TEST PDF DOWNLOAD
        </button>
        <p className="text-red-700 mt-3 text-lg">
          This button tests if PDF downloads work in your browser
        </p>
      </div>

      {/* ESG Health Score Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Overall ESG Score</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {esgScore?.overallScore || "74"}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  {getTrendIcon("up")}
                  <span className="ml-1">+3.2 from last quarter</span>
                </p>
              </div>
              <div className="w-16 h-16 bg-esg-primary/10 rounded-full flex items-center justify-center">
                <div className="w-12 h-12 bg-esg-primary rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A-</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Environmental</p>
                <p className="text-3xl font-bold text-esg-environmental mt-1">
                  {esgScore?.environmentalScore || "78"}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  {getTrendIcon("up")}
                  <span className="ml-1">+2.8 vs industry avg</span>
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Leaf className="h-6 w-6 text-esg-environmental" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Social</p>
                <p className="text-3xl font-bold text-esg-social mt-1">
                  {esgScore?.socialScore || "71"}
                </p>
                <p className="text-sm text-yellow-600 mt-1 flex items-center">
                  {getTrendIcon("down")}
                  <span className="ml-1">-1.2 vs industry avg</span>
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-esg-social" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Governance</p>
                <p className="text-3xl font-bold text-esg-governance mt-1">
                  {esgScore?.governanceScore || "73"}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  {getTrendIcon("up")}
                  <span className="ml-1">+4.1 vs industry avg</span>
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Shield className="h-6 w-6 text-esg-governance" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Regulatory Compliance Dashboard */}
      <Card className="esg-card">
        <CardHeader>
          <CardTitle>Regulatory Compliance Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "EU CSRD", status: "compliant", nextReport: "Q1 2025" },
              { name: "SEC Climate Rules", status: "in_progress", nextReport: "March 2025" },
              { name: "TCFD", status: "compliant", nextReport: "Updated Dec 2024" },
              { name: "GRI Standards", status: "compliant", nextReport: "Framework 2023" },
            ].map((framework) => {
              const statusInfo = getComplianceStatus(framework.status);
              const StatusIcon = statusInfo.icon;
              
              return (
                <div key={framework.name} className="text-center">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                    <StatusIcon className={`h-6 w-6 ${statusInfo.color}`} />
                  </div>
                  <h3 className="font-medium text-gray-900">{framework.name}</h3>
                  <p className={`text-sm ${statusInfo.color}`}>{statusInfo.text}</p>
                  <p className="text-xs text-gray-500 mt-1">{framework.nextReport}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* GHG Emissions Trends */}
        <Card className="esg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              GHG Emissions Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg flex items-center justify-center mb-4">
              <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-gray-900">-18.5%</p>
                <p className="text-sm text-gray-600">YoY Emissions Reduction</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-lg font-semibold text-gray-900">12,450</p>
                <p className="text-xs text-gray-500">Scope 1 (tCO₂e)</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-gray-900">28,730</p>
                <p className="text-xs text-gray-500">Scope 2 (tCO₂e)</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-gray-900">156,890</p>
                <p className="text-xs text-gray-500">Scope 3 (tCO₂e)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Industry Benchmarking */}
        <Card className="esg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Industry Benchmarking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center mb-4">
              <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-esg-primary">Top 25%</p>
                <p className="text-sm text-gray-600">Industry Ranking</p>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">S&P 500 ESG Score</span>
                <span className="text-sm font-medium text-gray-900">74 / 68 avg</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">FTSE4Good Inclusion</span>
                <Badge className="bg-green-100 text-green-800">Included</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">DJSI World Index</span>
                <Badge className="bg-green-100 text-green-800">Member</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Interactive ESG Score Adjustment System */}
      <Card className="esg-card">
        <CardHeader>
          <CardTitle>Interactive ESG Score Parameters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Environmental Parameters */}
            <div className="space-y-4">
              <h3 className="font-medium text-esg-environmental">Environmental Parameters</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Renewable Energy %
                  </label>
                  <Slider
                    value={[parameters.renewableEnergy]}
                    onValueChange={(value) => handleParameterChange('renewableEnergy', value[0])}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="font-medium text-esg-environmental">
                      {parameters.renewableEnergy}%
                    </span>
                    <span>100%</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Emissions Reduction Target
                  </label>
                  <Slider
                    value={[parameters.emissionsReduction]}
                    onValueChange={(value) => handleParameterChange('emissionsReduction', value[0])}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="font-medium text-esg-environmental">
                      {parameters.emissionsReduction}%
                    </span>
                    <span>50%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Parameters */}
            <div className="space-y-4">
              <h3 className="font-medium text-esg-social">Social Parameters</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Board Diversity %
                  </label>
                  <Slider
                    value={[parameters.boardDiversity]}
                    onValueChange={(value) => handleParameterChange('boardDiversity', value[0])}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="font-medium text-esg-social">
                      {parameters.boardDiversity}%
                    </span>
                    <span>100%</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Safety Training Hours
                  </label>
                  <Slider
                    value={[parameters.safetyTraining]}
                    onValueChange={(value) => handleParameterChange('safetyTraining', value[0])}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0h</span>
                    <span className="font-medium text-esg-social">
                      {parameters.safetyTraining}h
                    </span>
                    <span>100h</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Governance Parameters */}
            <div className="space-y-4">
              <h3 className="font-medium text-esg-governance">Governance Parameters</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Independent Directors %
                  </label>
                  <Slider
                    value={[parameters.independentDirectors]}
                    onValueChange={(value) => handleParameterChange('independentDirectors', value[0])}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="font-medium text-esg-governance">
                      {parameters.independentDirectors}%
                    </span>
                    <span>100%</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ESG Compensation Link %
                  </label>
                  <Slider
                    value={[parameters.esgCompensation]}
                    onValueChange={(value) => handleParameterChange('esgCompensation', value[0])}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span className="font-medium text-esg-governance">
                      {parameters.esgCompensation}%
                    </span>
                    <span>50%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Real-time Impact Visualization */}
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-3">Parameter Impact on Overall ESG Score</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-esg-environmental">78</div>
                <div className="text-sm text-gray-600">Environmental</div>
                <div className="text-xs text-green-600">+2 from adjustments</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-esg-social">71</div>
                <div className="text-sm text-gray-600">Social</div>
                <div className="text-xs text-green-600">+1 from adjustments</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-esg-governance">73</div>
                <div className="text-sm text-gray-600">Governance</div>
                <div className="text-xs text-green-600">+3 from adjustments</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Quick Actions */}
        <Card className="esg-card">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <button 
                className="w-full flex items-center justify-between p-3 border border-red-500 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
                onClick={async () => {
                  try {
                    console.log('Testing PDF generation directly...');
                    alert('Starting PDF test...');
                    
                    // Simple text download first
                    const content = `ESG Report Test - ${new Date().toLocaleString()}\n\nThis confirms downloads work!\n\nESG Data:\n- GHG Emissions: 45,230 tCO2e\n- Renewable Energy: 45%\n- Water Usage: 125,000 m³`;
                    const blob = new Blob([content], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = 'ESG_Test.txt';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                    
                    console.log('Text download completed');
                    alert('Text file downloaded! Now trying PDF...');
                    
                    // Try PDF generation
                    const jsPDFModule = await import('jspdf');
                    const jsPDF = jsPDFModule.default;
                    const pdf = new jsPDF();
                    pdf.text('ESG TEST REPORT', 20, 20);
                    pdf.text(`Generated: ${new Date().toLocaleString()}`, 20, 40);
                    pdf.text('Sample ESG Metrics:', 20, 60);
                    pdf.text('GHG Emissions: 45,230 tCO2e', 20, 80);
                    pdf.text('Renewable Energy: 45%', 20, 100);
                    pdf.save('ESG_PDF_Test.pdf');
                    
                    alert('SUCCESS! PDF downloaded. Check your downloads folder.');
                  } catch (error) {
                    console.error('Error:', error);
                    alert(`ERROR: ${error.message}`);
                  }
                }}
              >
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5 text-red-600" />
                  <span className="font-medium text-red-800">🔴 TEST PDF DOWNLOAD NOW</span>
                </div>
                <span className="text-red-400">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5 text-esg-secondary" />
                  <span className="font-medium">Generate CSRD Report</span>
                </div>
                <span className="text-gray-400">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-3">
                  <Upload className="h-5 w-5 text-esg-primary" />
                  <span className="font-medium">Upload Emissions Data</span>
                </div>
                <span className="text-gray-400">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-3">
                  <TrendingUp className="h-5 w-5 text-yellow-600" />
                  <span className="font-medium">Set New Targets</span>
                </div>
                <span className="text-gray-400">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-3">
                  <UserCheck className="h-5 w-5 text-purple-600" />
                  <span className="font-medium">Schedule Audit</span>
                </div>
                <span className="text-gray-400">→</span>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="esg-card">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Q4 2024 GHG emissions data validated</p>
                  <p className="text-xs text-gray-500">2 hours ago • System</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">TCFD report approved by board</p>
                  <p className="text-xs text-gray-500">1 day ago • Board of Directors</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Supplier ESG assessment reminder</p>
                  <p className="text-xs text-gray-500">2 days ago • Supply Chain</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Renewable energy targets updated</p>
                  <p className="text-xs text-gray-500">3 days ago • Sustainability Team</p>
                </div>
              </div>
            </div>
            <button className="w-full mt-4 text-center text-sm text-esg-secondary hover:text-esg-secondary/80 font-medium">
              View All Activity
            </button>
          </CardContent>
        </Card>
      </div>

      {/* Report Generator Dialog */}
      <Dialog open={showReportGenerator} onOpenChange={setShowReportGenerator}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Generate Comprehensive ESG Report</DialogTitle>
          </DialogHeader>
          <ReportGenerator
            defaultModule="Executive Dashboard"
            defaultReportType="comprehensive"
            onClose={() => setShowReportGenerator(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
