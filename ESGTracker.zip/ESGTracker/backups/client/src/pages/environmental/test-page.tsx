import React from "react";

export default function TestPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-green-600">TEST PAGE WORKING!</h1>
      <p className="text-gray-600 mt-4">This test page confirms routing is functional.</p>
    </div>
  );
}