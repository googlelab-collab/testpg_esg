import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import LoadingSpinner from "@/components/common/LoadingSpinner";
import ErrorMessage from "@/components/common/ErrorMessage";
import { 
  Flower, 
  TreePine, 
  Shield, 
  MapPin, 
  TrendingUp,
  Settings,
  FileText,
  Target,
  Leaf,
  Bird
} from "lucide-react";

const organizationId = 1;

export default function Biodiversity() {
  const [parameters, setParameters] = useState({
    habitatConservation: 70,
    speciesProtection: 60,
    restorationInvestment: 55,
    supplierBiodiversity: 45,
  });

  const { data: biodiversityData, isLoading, error } = useQuery({
    queryKey: ["/api/environmental-metrics", organizationId],
    select: (data) => data?.filter((metric: any) => metric.metricType === "biodiversity") || [],
    retry: false,
  });

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message="Failed to load biodiversity data" />;

  const handleParameterChange = (parameter: string, value: number) => {
    setParameters(prev => ({ ...prev, [parameter]: value }));
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Biodiversity Impact Assessor</h1>
          <p className="text-gray-600 mt-1">
            Biodiversity conservation following CBD Global Biodiversity Framework and TNFD recommendations
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Biodiversity Report
          </Button>
          <Button className="flex items-center gap-2 esg-primary">
            <Target className="h-4 w-4" />
            Set Nature Targets
          </Button>
        </div>
      </div>

      {/* Biodiversity Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Protected Areas</p>
                <p className="text-2xl font-bold text-green-600">2,340</p>
                <p className="text-xs text-green-600">12% of operations</p>
              </div>
              <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center">
                <Shield className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-2">
              <p className="text-xs text-gray-500">hectares conserved</p>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Species Supported</p>
                <p className="text-2xl font-bold text-blue-600">47</p>
                <p className="text-xs text-blue-600">Including 8 threatened</p>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                <Bird className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-2">
              <p className="text-xs text-gray-500">conservation programs</p>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Habitat Restored</p>
                <p className="text-2xl font-bold text-purple-600">890</p>
                <p className="text-xs text-green-600">+245 ha this year</p>
              </div>
              <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center">
                <TreePine className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-2">
              <p className="text-xs text-gray-500">hectares restored</p>
            </div>
          </CardContent>
        </Card>

        <Card className="esg-score-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Biodiversity Score</p>
                <p className="text-2xl font-bold text-orange-600">7.2</p>
                <p className="text-xs text-green-600">+0.8 vs baseline</p>
              </div>
              <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center">
                <Flower className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="mt-2">
              <p className="text-xs text-gray-500">ecosystem health index</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Biodiversity Impact Assessment */}
        <div className="lg:col-span-2">
          <Card className="esg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flower className="h-5 w-5" />
                Biodiversity Impact Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="ecosystems" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="ecosystems">Ecosystems</TabsTrigger>
                  <TabsTrigger value="species">Species</TabsTrigger>
                  <TabsTrigger value="threats">Threats</TabsTrigger>
                </TabsList>
                
                <TabsContent value="ecosystems" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Forest Ecosystems</span>
                      <span className="text-sm text-gray-600">1,250 ha (53%)</span>
                    </div>
                    <Progress value={53} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Wetland Areas</span>
                      <span className="text-sm text-gray-600">520 ha (22%)</span>
                    </div>
                    <Progress value={22} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Grassland Habitats</span>
                      <span className="text-sm text-gray-600">390 ha (17%)</span>
                    </div>
                    <Progress value={17} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Marine Protected</span>
                      <span className="text-sm text-gray-600">180 ha (8%)</span>
                    </div>
                    <Progress value={8} className="h-2" />
                  </div>
                </TabsContent>
                
                <TabsContent value="species" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Critically Endangered</span>
                      <span className="text-sm text-red-600">2 species</span>
                    </div>
                    <Progress value={4} className="h-2 bg-red-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Endangered</span>
                      <span className="text-sm text-orange-600">6 species</span>
                    </div>
                    <Progress value={13} className="h-2 bg-orange-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Vulnerable</span>
                      <span className="text-sm text-yellow-600">12 species</span>
                    </div>
                    <Progress value={26} className="h-2 bg-yellow-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Least Concern</span>
                      <span className="text-sm text-green-600">27 species</span>
                    </div>
                    <Progress value={57} className="h-2 bg-green-100" />
                  </div>
                </TabsContent>
                
                <TabsContent value="threats" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Habitat Fragmentation</span>
                      <span className="text-sm text-red-600">High risk</span>
                    </div>
                    <Progress value={75} className="h-2 bg-red-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Climate Change</span>
                      <span className="text-sm text-orange-600">Medium risk</span>
                    </div>
                    <Progress value={55} className="h-2 bg-orange-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Pollution Impact</span>
                      <span className="text-sm text-yellow-600">Low-Medium risk</span>
                    </div>
                    <Progress value={35} className="h-2 bg-yellow-100" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Invasive Species</span>
                      <span className="text-sm text-green-600">Low risk</span>
                    </div>
                    <Progress value={20} className="h-2 bg-green-100" />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Biodiversity Conservation Parameters */}
        <div>
          <Card className="esg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Conservation Parameters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium">Habitat Conservation</label>
                  <Badge variant="outline">{parameters.habitatConservation}%</Badge>
                </div>
                <Slider
                  value={[parameters.habitatConservation]}
                  onValueChange={(value) => handleParameterChange('habitatConservation', value[0])}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Operations in protected areas
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium">Species Protection</label>
                  <Badge variant="outline">{parameters.speciesProtection}%</Badge>
                </div>
                <Slider
                  value={[parameters.speciesProtection]}
                  onValueChange={(value) => handleParameterChange('speciesProtection', value[0])}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Threatened species supported
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium">Restoration Investment</label>
                  <Badge variant="outline">{parameters.restorationInvestment}%</Badge>
                </div>
                <Slider
                  value={[parameters.restorationInvestment]}
                  onValueChange={(value) => handleParameterChange('restorationInvestment', value[0])}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Habitat restoration funding
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium">Supplier Biodiversity</label>
                  <Badge variant="outline">{parameters.supplierBiodiversity}%</Badge>
                </div>
                <Slider
                  value={[parameters.supplierBiodiversity]}
                  onValueChange={(value) => handleParameterChange('supplierBiodiversity', value[0])}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Suppliers with biodiversity policies
                </p>
              </div>

              <Button className="w-full esg-primary">
                Apply Changes
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Science-Based Targets for Nature */}
      <Card className="esg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Science-Based Targets for Nature (SBTN)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-600" />
                <span className="font-medium">No Net Loss</span>
              </div>
              <p className="text-sm text-gray-600">
                Achieve no net loss by 2025
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>78%</span>
                </div>
                <Progress value={78} className="h-2" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <span className="font-medium">Net Positive</span>
              </div>
              <p className="text-sm text-gray-600">
                Net positive impact by 2030
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>35%</span>
                </div>
                <Progress value={35} className="h-2" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <TreePine className="h-5 w-5 text-purple-600" />
                <span className="font-medium">Restoration</span>
              </div>
              <p className="text-sm text-gray-600">
                1,500 hectares restored by 2030
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>59%</span>
                </div>
                <Progress value={59} className="h-2" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Leaf className="h-5 w-5 text-green-500" />
                <span className="font-medium">Supply Chain</span>
              </div>
              <p className="text-sm text-gray-600">
                Zero deforestation supply chains
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Coverage</span>
                  <span>82%</span>
                </div>
                <Progress value={82} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
