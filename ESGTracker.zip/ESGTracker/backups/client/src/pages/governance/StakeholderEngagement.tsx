import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MessageSquare, Users, TrendingUp, Target } from "lucide-react";

export default function StakeholderEngagement() {
  const engagementMetrics = {
    satisfaction: 84,
    participation: 76,
    feedback: 92,
    transparency: 88
  };

  const stakeholderGroups = {
    investors: 91,
    employees: 85,
    customers: 79,
    communities: 73
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Stakeholder Engagement</h1>
          <p className="text-muted-foreground">Monitor stakeholder relationships and engagement quality</p>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          Engagement Score: B+
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Satisfaction</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagementMetrics.satisfaction}%</div>
            <p className="text-xs text-muted-foreground">overall satisfaction</p>
            <Progress value={engagementMetrics.satisfaction} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Participation</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagementMetrics.participation}%</div>
            <p className="text-xs text-muted-foreground">active participation</p>
            <Progress value={engagementMetrics.participation} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Feedback Quality</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagementMetrics.feedback}%</div>
            <p className="text-xs text-muted-foreground">constructive feedback</p>
            <Progress value={engagementMetrics.feedback} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transparency</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagementMetrics.transparency}%</div>
            <p className="text-xs text-muted-foreground">disclosure rating</p>
            <Progress value={engagementMetrics.transparency} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Stakeholder Groups</CardTitle>
            <CardDescription>Engagement scores by stakeholder category</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Investors</span>
                <span className="text-sm text-muted-foreground">{stakeholderGroups.investors}%</span>
              </div>
              <Progress value={stakeholderGroups.investors} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Employees</span>
                <span className="text-sm text-muted-foreground">{stakeholderGroups.employees}%</span>
              </div>
              <Progress value={stakeholderGroups.employees} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Customers</span>
                <span className="text-sm text-muted-foreground">{stakeholderGroups.customers}%</span>
              </div>
              <Progress value={stakeholderGroups.customers} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Communities</span>
                <span className="text-sm text-muted-foreground">{stakeholderGroups.communities}%</span>
              </div>
              <Progress value={stakeholderGroups.communities} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Engagement Activities</CardTitle>
            <CardDescription>Key engagement initiatives and frequency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Annual General Meeting</span>
                <Badge variant="outline" className="text-green-600">Annual</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Quarterly Investor Calls</span>
                <Badge variant="outline" className="text-green-600">Quarterly</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Employee Surveys</span>
                <Badge variant="outline" className="text-green-600">Bi-annual</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Community Forums</span>
                <Badge variant="outline" className="text-green-600">Monthly</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}