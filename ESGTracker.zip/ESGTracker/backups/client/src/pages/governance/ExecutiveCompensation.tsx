import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { DollarSign, Target, TrendingUp, Users } from "lucide-react";

export default function ExecutiveCompensation() {
  const compensationMetrics = {
    esgAlignment: 78,
    payEquity: 92,
    disclosure: 88,
    payRatio: 247
  };

  const compensationStructure = {
    base: 35,
    variable: 45,
    longTerm: 20
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Executive Compensation</h1>
          <p className="text-muted-foreground">Track executive pay practices and ESG alignment</p>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          Compensation Score: B+
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ESG Alignment</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{compensationMetrics.esgAlignment}%</div>
            <p className="text-xs text-muted-foreground">of variable pay</p>
            <Progress value={compensationMetrics.esgAlignment} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pay Equity</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{compensationMetrics.payEquity}%</div>
            <p className="text-xs text-muted-foreground">gender pay parity</p>
            <Progress value={compensationMetrics.payEquity} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disclosure Score</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{compensationMetrics.disclosure}%</div>
            <p className="text-xs text-muted-foreground">transparency rating</p>
            <Progress value={compensationMetrics.disclosure} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CEO Pay Ratio</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{compensationMetrics.payRatio}:1</div>
            <p className="text-xs text-muted-foreground">vs median worker</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Compensation Structure</CardTitle>
            <CardDescription>Breakdown of executive compensation components</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Base Salary</span>
                <span className="text-sm text-muted-foreground">{compensationStructure.base}%</span>
              </div>
              <Progress value={compensationStructure.base} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Variable Pay</span>
                <span className="text-sm text-muted-foreground">{compensationStructure.variable}%</span>
              </div>
              <Progress value={compensationStructure.variable} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Long-term Incentives</span>
                <span className="text-sm text-muted-foreground">{compensationStructure.longTerm}%</span>
              </div>
              <Progress value={compensationStructure.longTerm} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ESG Performance Metrics</CardTitle>
            <CardDescription>How executive pay aligns with ESG goals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Carbon Reduction Target</span>
                <span className="text-sm font-bold">25%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Diversity Goals</span>
                <span className="text-sm font-bold">20%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Safety Metrics</span>
                <span className="text-sm font-bold">15%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Governance Score</span>
                <span className="text-sm font-bold">18%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}